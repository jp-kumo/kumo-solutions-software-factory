# Slack Launch Messages

## 1. Chief of Staff → `#agent-control-tower`
**Project #1 is now activated.**

- **Objective:** <business objective>
- **Priority:** <why now>
- **Current phase:** Intake / kickoff
- **Main Orchestrator:** active
- **Security/Compliance Agent:** active
- **Rule:** no implementation work begins until the earliest missing gate is satisfied
- **Security rule:** security-by-design is mandatory; no release without security GO / CONDITIONAL GO / NO-GO

## 2. Main Orchestrator → `#agent-control-tower`
**Kickoff routing decision**

- **Project:** <name>
- **Current stage:** <stage>
- **Earliest missing gate:** <gate>
- **Owner:** <owner>
- **Required skill:** <skill>
- **Decision:** GO / CONDITIONAL GO / NO-GO
- **Ready for next stage:** YES / NO

## 3. Security/Compliance Agent → `#proj-<name>-arch` or `#proj-<name>-security`
**Security kickoff**

- **Scope:** web / api / mobile / backend
- **Baseline standards:** OWASP Top 10:2025, ASVS 5.0.0, API Top 10 2023, MASVS as applicable
- **Immediate tasks:** security design intake, threat model, abuse cases
- **Release blocking rule:** critical findings or incomplete required evidence = NO-GO

## 4. Chief of Staff → project intake channel
**Project packet approved**

- **In scope:**  
- **Out of scope:**  
- **Success criteria:**  
- **Milestone:**  
- **Escalation path:** Chief of Staff → User

## 5. Daily control-tower template
**Daily status**
- **Current stage:**  
- **Earliest missing gate:**  
- **Functional status:**  
- **Security status:**  
- **Top blockers:**  
- **Decision needed:**  
- **Recommendation:** Continue / Slow intake / Pause / Escalate
