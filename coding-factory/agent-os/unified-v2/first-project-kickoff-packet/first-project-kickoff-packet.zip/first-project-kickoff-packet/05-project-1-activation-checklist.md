# Project #1 Activation Checklist

## A. Factory readiness
- [ ] v2 environment selected as source of truth
- [ ] Chief of Staff prompt installed
- [ ] Main-agent launcher prompt installed
- [ ] Main-agent prompt stack installed
- [ ] Master Orchestrator skill installed
- [ ] Handoff-enforcement skill pack installed
- [ ] Security gate skill pack installed
- [ ] Role skill pack installed
- [ ] Security/Compliance Agent prompt installed
- [ ] Active-files-only cheat sheet distributed

## B. Repo readiness
- [ ] live factory root selected
- [ ] sample monorepo unpacked
- [ ] repo initialized in source control
- [ ] branch protection / PR policy chosen
- [ ] CI workflow visible and understood
- [ ] local secrets handling approach selected

## C. Slack readiness
- [ ] `#agent-control-tower` created
- [ ] project channel family created
- [ ] canvases installed
- [ ] lists installed
- [ ] workflows/forms installed
- [ ] kickoff messages posted

## D. Project readiness
- [ ] project objective approved
- [ ] in-scope / out-of-scope written
- [ ] success criteria written
- [ ] milestone date chosen
- [ ] named project owner set
- [ ] risk tolerance stated
- [ ] first stage identified

## E. Security readiness
- [ ] sensitive data identified
- [ ] external surfaces identified
- [ ] trust boundaries identified
- [ ] authn/authz expectations identified
- [ ] dependency / third-party exposure identified
- [ ] security design intake assigned
- [ ] threat model assigned

## F. Gate readiness
- [ ] feature brief / dispatch gate complete
- [ ] architecture RFC gate complete
- [ ] API/data contract gate complete or explicitly not needed
- [ ] security design intake complete
- [ ] threat model / abuse cases complete
- [ ] implementation handoff ready
- [ ] QA/test plan ready

## G. Green-light rule
Project #1 may start implementation only when all required items in sections D, E, and F are complete and the Main Orchestrator returns:
- **Decision: GO**
- **Ready for next stage: YES**
