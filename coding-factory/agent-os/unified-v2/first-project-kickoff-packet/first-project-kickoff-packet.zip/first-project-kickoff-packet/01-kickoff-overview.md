# Project #1 Kickoff Overview

## Mission
Launch the first project using the Coding Factory so the team proves it can:
- scope work cleanly
- enforce handoff gates
- enforce security-by-design
- ship a small but real deliverable
- produce repeatable evidence for future projects

## Chain of command
1. **User / Executive sponsor**
   - sets business objective, priority, and risk tolerance
   - approves explicit risk acceptance when needed
2. **Chief of Staff**
   - owns intake, prioritization, staffing, executive communication, and WIP control
   - approves work packets for the Main Orchestrator
3. **Main Orchestrator**
   - owns stage detection, earliest-missing-gate logic, work routing, and GO/NO-GO recommendations
4. **Subagents**
   - Architect
   - Web
   - Mobile
   - API/Data
   - QA/Test
   - Platform/Release
   - Security/Compliance

## Non-negotiable operating rules
1. No coding starts until the earliest missing gate is satisfied.
2. No release starts until both functional and security release gates are satisfied.
3. Security is part of the default lifecycle, not an optional review lane.
4. Slack is the coordination layer; Git is the code source of truth.
5. Every handoff must include artifacts, evidence, risks, and the next owner.
6. Every release recommendation ends with **GO**, **CONDITIONAL GO**, or **NO-GO**.

## Default lifecycle
1. Intake and feature brief
2. Architecture RFC
3. API/data contract
4. Security design intake
5. Threat model and abuse cases
6. Implementation handoff
7. QA/test plan
8. Security verification
   - OWASP Top 10:2025 review
   - ASVS control mapping
   - API Top 10 review
   - MASVS review for mobile
9. Functional release readiness
10. Security release readiness
11. Post-release review

## Project #1 success criteria
The first project is successful if:
- the team uses the official v2 stack and no superseded packs
- all required gates are completed in order
- the team ships a small, working deliverable
- security findings are tracked and dispositioned
- the Chief of Staff can summarize status in one page
- the Main Orchestrator can prove why work is or is not allowed to advance

## Recommended scope for project #1
Pick something small and verifiable:
- account signup/login shell
- user profile/settings app
- lightweight dashboard with auth
- simple CRUD workflow with web + API, and optional mobile shell

## Default artifacts required before coding
- project objective
- in-scope / out-of-scope list
- success criteria
- architecture RFC
- API contract or contract decision
- security design intake
- threat model
- implementation handoff
- QA/test plan
