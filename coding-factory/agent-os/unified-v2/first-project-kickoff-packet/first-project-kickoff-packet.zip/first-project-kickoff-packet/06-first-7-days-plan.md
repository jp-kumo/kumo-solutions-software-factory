# First 7 Days Plan

## Day 1 — Activate the factory
- Chief of Staff confirms v2 source of truth
- Main Orchestrator confirms routing stack
- Security/Compliance Agent confirms baseline standards
- Slack project channels are created
- Project objective and scope are approved

## Day 2 — Lock the work packet
- feature brief / dispatch completed
- architecture RFC assigned or completed
- project assumptions called out explicitly
- unknowns turned into decision items

## Day 3 — Lock architecture and contracts
- architecture RFC completed
- API/data contract completed or declared not needed
- implementation boundaries written
- primary dependencies identified

## Day 4 — Lock security design
- security design intake completed
- threat model completed
- abuse cases completed
- required security reviews identified by scope

## Day 5 — Lock implementation and test handoffs
- implementation handoff completed
- QA/test plan completed
- test environments / local setup clarified
- release assumptions documented

## Day 6 — Start controlled build work
- only now route to coding subagents
- enforce small PRs / small work slices
- collect early test evidence
- collect early security evidence

## Day 7 — First control review
- Chief of Staff publishes executive summary
- Main Orchestrator publishes stage/gate status
- Security/Compliance Agent publishes security status
- confirm whether project remains GO, CONDITIONAL GO, or NO-GO

## Rule for all 7 days
If any required artifact becomes unclear, missing, or contradicted, stop and return to the earliest missing gate.
