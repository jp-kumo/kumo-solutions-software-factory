# SUPERSEDED PACKS

Treat the following earlier bundles as **superseded for active setup**:

- `agent-os-repo-starter.zip`
- `agent-os-sample-monorepo-starter.zip`
- `main-agent-system-prompt.zip`
- `main-agent-system-prompt-suite.zip`
- `main-agent-launcher-prompt.zip`
- `main-agent-prompt-stack-assembled.zip`
- `chief-of-staff-system-prompt.zip`
- `security-compliance-agent-prompt.zip`
- `security-integrated-factory-updates.zip`

You can keep them for reference, but the team should install from the **security-integrated v2 packs** instead.
