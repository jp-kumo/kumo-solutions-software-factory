# Quick Start — Security-Integrated v2

This quick start is for the **repo package**.

## Step 1
Read:
- `README.md`
- `docs/security-baseline.md`
- `docs/install-order-v2.md`

## Step 2
Install the prompts in this order:
1. `prompts/chief-of-staff/`
2. `prompts/launcher/`
3. `prompts/main-agent/`
4. `prompts/security-compliance-agent/`

## Step 3
Install the skills in this order:
1. `skills/orchestrator/master-orchestrator-skill/`
2. `skills/enforcement/`
3. `skills/security-gates/`
4. `skills/roles/`
5. `skills/domain/`

## Step 4
Stand up the Slack assets:
- `slack/channel-templates/`
- `slack/canvas-templates/`
- `slack/workflow-templates/`
- `slack/list-templates/`

## Step 5
Run a pilot project using the full gate sequence:
- feature brief
- architecture RFC
- API contract
- implementation handoff
- QA/test plan
- security reviews and mappings
- release readiness
- post-release review

## Rule
If the earliest missing gate is security-related, **the work stops** until the gate is satisfied or you explicitly accept risk.
