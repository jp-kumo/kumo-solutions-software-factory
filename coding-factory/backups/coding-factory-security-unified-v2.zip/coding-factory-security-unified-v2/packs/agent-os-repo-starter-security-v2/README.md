# Agent OS Repo Starter — Security-Integrated v2

This is the **updated source-of-truth repository starter** for your Coding Factory.  
It consolidates the original operating-system assets with the later **security-by-design** updates so your team has one clear package to install.

## What is new in v2
- Security is now a **default lifecycle gate**
- The Chief of Staff prompt now treats security as a portfolio-level constraint
- The launcher and main-agent prompts can auto-escalate to full governance on security triggers
- The Master Orchestrator can route to security gate skills and block work when security artifacts are missing
- The default output schema now includes security posture, findings summary, risk acceptance, and release blockers

## What this package contains
- **docs/** — operating manual, quick start, migration guide, install order, and security baseline
- **prompts/** — launcher, main-agent, chief-of-staff, and security-compliance prompts
- **skills/** — orchestrator, handoff-enforcement, role, domain, and security gate skills
- **templates/** — handoff templates
- **slack/** — channel, canvas, workflow, and list templates
- **schemas/** — security-integrated default output schema
- **config/** — stack map and implementation references

## Recommended top-level reading order
1. `docs/quick-start.md`
2. `docs/security-baseline.md`
3. `docs/install-order-v2.md`
4. `config/agent-stack-map.md`

## Single source of truth rule
Use this v2 package as the **authoritative pack**.  
Earlier standalone bundles should be considered **superseded for active setup**, even if you still keep them for reference.
