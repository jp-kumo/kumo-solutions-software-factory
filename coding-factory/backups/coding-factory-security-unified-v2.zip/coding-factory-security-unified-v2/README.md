# Coding Factory Security-Integrated v2

This bundle consolidates your updated Coding Factory packs into a single source-of-truth family so your Chief of Staff, Main Orchestrator, and subagents all reference the same assets.

## Contents
- `packs/agent-os-repo-starter-security-v2/`
- `packs/agent-os-sample-monorepo-starter-security-v2/`
- `START-HERE.md`
- `VERSION-MANIFEST.md`
- `SUPERSEDED-PACKS.md`
- `MIGRATION-SUMMARY.md`
- `RELEASE-NOTES-v2.md`

## Recommended default
Use `packs/agent-os-sample-monorepo-starter-security-v2/` if you want both the operating system and a starter code scaffold.

Use `packs/agent-os-repo-starter-security-v2/` if you want the operating system only.
