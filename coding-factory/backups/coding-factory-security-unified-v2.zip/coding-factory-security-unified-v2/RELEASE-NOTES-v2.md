# RELEASE NOTES — Security-Integrated v2

## Why this version exists
The earlier assets were produced incrementally. This version consolidates them so the team has a clearer installation target and built-in security gates.

## Major changes
- Security is part of the default workflow
- The Chief of Staff, launcher, main-agent prompts, orchestrator skill, and schema all understand security gates
- Security gate skills are bundled directly into the repo and monorepo starters
- New docs clarify install order and migration

## Operator guidance
Use only these v2 packs for active setup and onboarding.
