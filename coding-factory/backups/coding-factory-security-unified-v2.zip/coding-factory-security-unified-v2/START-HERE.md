# START HERE — Coding Factory Security-Integrated v2

This folder is the **single source of truth** for the current Coding Factory packs.

## Use these packs
1. `packs/agent-os-repo-starter-security-v2/`
2. `packs/agent-os-sample-monorepo-starter-security-v2/`

## Ignore these older packs for active setup
- original repo starter
- original sample monorepo starter
- standalone prompt bundles
- standalone security update bundles

Keep older packs only for reference if needed.

## Which pack should you use?
- Use the **repo starter security v2** if you want the operating system only.
- Use the **sample monorepo starter security v2** if you want the operating system plus a starter app scaffold.

## First files to read
1. `VERSION-MANIFEST.md`
2. `SUPERSEDED-PACKS.md`
3. `packs/agent-os-repo-starter-security-v2/docs/quick-start.md`
4. `packs/agent-os-repo-starter-security-v2/docs/security-baseline.md`
