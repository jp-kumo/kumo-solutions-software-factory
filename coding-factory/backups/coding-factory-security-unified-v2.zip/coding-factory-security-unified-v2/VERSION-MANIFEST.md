# VERSION MANIFEST

## Current package family
- **Coding Factory Security-Integrated v2**

## Included packs
- `agent-os-repo-starter-security-v2`
- `agent-os-sample-monorepo-starter-security-v2`

## Integrated updates
- Chief of Staff security-integrated prompt
- Main-agent security-integrated prompt set
- security-integrated launcher prompt
- security-integrated assembled prompt stack
- security-integrated master orchestrator skill
- security-integrated default output schema
- Security/Compliance Agent prompt
- security gate skill pack

## Intent
Reduce confusion by giving the team one package family to install and reference.
