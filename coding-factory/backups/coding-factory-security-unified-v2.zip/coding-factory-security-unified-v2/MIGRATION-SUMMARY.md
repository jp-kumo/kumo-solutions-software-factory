# MIGRATION SUMMARY

If the team already downloaded older bundles, do not mix and match them manually.

Instead:
1. Pick the correct v2 pack from `packs/`
2. Replace older prompt files with the versions in that pack
3. Replace the older orchestrator skill with the v2 orchestrator skill
4. Add the `skills/security-gates/` directory
5. Replace the old schema with the v2 schema
6. Update internal docs to point at `START-HERE.md`

This avoids overlap between pre-security and post-security bundles.
