# Mobile Implementation Handoff Template

## Header
- **Feature ID:** [FEATURE_ID]
- **Status:** DRAFT
- **Author:** Mobile Agent
- **Next Owner:** [QA / PLATFORM / MAIN AGENT]
- **Related brief:** [LINK]
- **Related contract:** [LINK]

## Scope completed
- [Screen/flow]
- [Navigation/state]
- [Permissions/device integration]
- [Analytics/observability]

## Files and modules changed
- [Path or module]
- [Path or module]

## Platform coverage
- [ ] iOS
- [ ] Android
- [ ] Tablets/orientation assessed if applicable
- [ ] Web parity considered if applicable

## UX states covered
- [ ] loading
- [ ] empty
- [ ] success
- [ ] validation error
- [ ] API/server error
- [ ] offline/degraded network state
- [ ] permission denied state

## Mobile-specific checks
- [ ] Safe area / notch behavior
- [ ] Keyboard handling
- [ ] Deep links/universal links if applicable
- [ ] Background/foreground transition behavior
- [ ] Analytics/crash reporting hooks

## Testing completed
### Unit/component tests
- [Test file/link]
- [Test file/link]

### Device/E2E notes
- [Flow]
- [Flow]

## Evidence
- [Build link]
- [Recording/screenshot]
- [Device matrix]

## Known limitations
- [Limitation]
- [Limitation]

## Risks
- [Risk + mitigation]
- [Risk + mitigation]

## Explicit asks to QA / next owner
- [Ask]
- [Ask]

## Ready for next stage when
- [ ] Acceptance criteria implemented
- [ ] Device coverage recorded
- [ ] Tests added/updated
- [ ] Evidence attached
