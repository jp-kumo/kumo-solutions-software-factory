# API Contract Handoff Template

## Header
- **Feature ID:** [FEATURE_ID]
- **Contract ID:** [CONTRACT_ID]
- **Status:** DRAFT
- **Author:** API/Data Agent
- **Next Owner:** [WEB / MOBILE / QA]
- **Related RFC:** [LINK]

## Contract summary
[Summarize what the API/data contract provides.]

## Endpoints / operations
### [METHOD] [PATH]
- **Purpose:** [What it does]
- **Auth:** [Required auth]
- **Idempotency:** [Yes/No + details]
- **Rate limits:** [If applicable]

#### Request
```json
{
  "example": "request"
}
```

#### Validation rules
- [Rule]
- [Rule]

#### Success response
```json
{
  "success": true
}
```

#### Error responses
- `400` — [Meaning]
- `401` — [Meaning]
- `403` — [Meaning]
- `404` — [Meaning]
- `409` — [Meaning]
- `500` — [Meaning]

### Additional endpoints/events
[Repeat as needed.]

## Versioning / compatibility
- [Versioning policy]
- [Deprecation notes]
- [Backward compatibility notes]

## Data model changes
- [Schema/table/index]
- [Migration or backfill]
- [Data cleanup or retention]

## Security notes
- [PII/secrets handling]
- [Authorization rules]
- [Input validation concerns]

## Observability notes
- [Structured log fields]
- [Metrics]
- [Tracing spans]
- [Audit events]

## Consumer guidance
### For web/mobile agents
- [How to call this safely]
- [Retry/error-state expectations]
- [Caching or pagination guidance]

### For QA
- [Critical cases to test]
- [Known negative cases]
- [Contract-test expectations]

## Ready for next stage when
- [ ] Schemas are finalized
- [ ] Example payloads are included
- [ ] Error cases are documented
- [ ] Migration notes are attached
