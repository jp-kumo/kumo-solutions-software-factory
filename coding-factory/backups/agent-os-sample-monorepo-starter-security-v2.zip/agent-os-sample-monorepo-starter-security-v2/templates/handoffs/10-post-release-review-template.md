# Post-Release Review Template

## Header
- **Release ID:** [RELEASE_ID]
- **Feature ID(s):** [FEATURE_IDS]
- **Status:** DRAFT
- **Author:** Main Agent / Platform Agent
- **Review date:** [DATE]

## What shipped
- [Item]
- [Item]

## Release outcome
- [ ] Successful / as expected
- [ ] Successful with issues
- [ ] Rollback required
- [ ] Incident triggered

## Production observations
- [Metric or observation]
- [Metric or observation]

## Monitoring and support signals
- error rate: [Value/trend]
- latency/perf: [Value/trend]
- crash rate: [Value/trend if mobile]
- support tickets/user reports: [Summary]

## What went well
- [Point]
- [Point]

## What did not go well
- [Point]
- [Point]

## Defects or incidents found after release
- [Issue + severity + owner]
- [Issue + severity + owner]

## Follow-up actions
- [Action + owner + due date]
- [Action + owner + due date]

## Process improvements
- [Improvement]
- [Improvement]

## Closeout decision
- [ ] Close release
- [ ] Keep under observation
- [ ] Open incident/problem record
