# Architecture RFC / Handoff Template

## Header
- **Feature ID:** [FEATURE_ID]
- **RFC ID:** [RFC_ID]
- **Status:** DRAFT
- **Author:** Architect Agent
- **Next Owner:** [API / WEB / MOBILE / PLATFORM / SECURITY]
- **Related brief:** [LINK]

## Summary
[1–2 paragraph summary of the proposed technical approach.]

## Decision statement
[State the architecture decision in one sentence.]

## Requirements this design satisfies
- [Requirement]
- [Requirement]
- [Requirement]

## System context
### Existing system
[Describe what exists today.]

### Proposed changes
[Describe what will be added/changed.]

## High-level design
### Components
- [Component]
- [Component]

### Data flow
1. [Step]
2. [Step]
3. [Step]

### Trust boundaries / auth boundaries
- [Boundary]
- [Boundary]

## API and contract impacts
- [Endpoint/event/schema impact]
- [Backward compatibility note]

## Data model impacts
- [Table/entity/index]
- [Migration requirement]
- [Retention/audit requirement]

## Failure modes and recovery
- [Failure mode] → [Detection] → [Recovery]
- [Failure mode] → [Detection] → [Recovery]

## Observability requirements
- logs: [Required]
- metrics: [Required]
- tracing: [Required]
- alerts: [Required]

## Security and privacy considerations
- [Threat or control]
- [Threat or control]

## Performance/scalability considerations
- [Load profile]
- [Latency budget]
- [Caching/rate limiting/concurrency note]

## Alternatives considered
1. [Alternative] — rejected because [reason]
2. [Alternative] — rejected because [reason]

## Risks
- [Risk + mitigation]
- [Risk + mitigation]

## Rollout and rollback
### Rollout plan
- [Step]
- [Step]

### Rollback plan
- [Step]
- [Step]

## Explicit asks to next owner
- [Ask]
- [Ask]

## Approval checklist
- [ ] Meets feature brief goals
- [ ] Data changes are understood
- [ ] Security concerns reviewed
- [ ] Observability plan defined
- [ ] Rollback plan documented
