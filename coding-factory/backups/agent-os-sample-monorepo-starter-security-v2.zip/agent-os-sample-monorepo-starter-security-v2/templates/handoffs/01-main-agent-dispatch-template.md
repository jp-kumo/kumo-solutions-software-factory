# Main Agent Dispatch Template

## Header
- **Feature ID:** [FEATURE_ID]
- **Title:** [SHORT_TITLE]
- **Status:** DRAFT
- **Priority:** [P0/P1/P2/P3]
- **Current Owner:** Main Agent
- **Next Owner:** [ARCHITECT / API / WEB / MOBILE / QA / PLATFORM / SECURITY]
- **Slack Thread:** [LINK]
- **Due Gate:** [DATE]

## Objective
[Describe the business/user outcome in 2–5 sentences.]

## Why this matters
- [Business reason]
- [User reason]
- [Technical/operational reason]

## Scope
### In scope
- [Item]
- [Item]

### Out of scope
- [Item]
- [Item]

## Acceptance criteria
- [ ] [Criterion 1]
- [ ] [Criterion 2]
- [ ] [Criterion 3]

## Dependencies
- [Dependency]
- [Dependency]

## Required artifacts
- [ ] Feature brief
- [ ] Architecture RFC / ADR
- [ ] API contract (if applicable)
- [ ] Web handoff (if applicable)
- [ ] Mobile handoff (if applicable)
- [ ] QA test plan
- [ ] Release readiness review

## Risks
- [Risk + likely impact]
- [Risk + likely impact]

## Instructions to next owner
[State exactly what the next owner must produce.]

## Definition of ready for next stage
- [Condition]
- [Condition]
