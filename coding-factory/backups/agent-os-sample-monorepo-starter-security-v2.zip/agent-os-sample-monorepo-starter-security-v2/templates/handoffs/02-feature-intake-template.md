# Feature Intake Template

## Request summary
- **Request ID:** [REQUEST_ID]
- **Submitted by:** [NAME/TEAM]
- **Date:** [DATE]
- **Requested priority:** [P0/P1/P2/P3]
- **Requested timeline:** [DATE OR WINDOW]

## Problem statement
[What problem exists today?]

## Desired outcome
[What should be true after this feature ships?]

## Primary users
- [User type]
- [User type]

## Example use cases
1. [Use case]
2. [Use case]
3. [Use case]

## Success metrics
- [Metric]
- [Metric]

## Constraints
- [Budget]
- [Compliance]
- [Platform]
- [Data]
- [Performance]
- [Timeline]

## Known dependencies
- [Dependency]
- [Dependency]

## Risks or concerns from requester
- [Risk]
- [Risk]

## Attachments/links
- [Link]
- [Link]

## Main agent triage
### Triage decision
- [ ] Accept into backlog
- [ ] Need clarification
- [ ] Reject / not now
- [ ] Convert to bug/incident

### Notes
[Main agent notes]
