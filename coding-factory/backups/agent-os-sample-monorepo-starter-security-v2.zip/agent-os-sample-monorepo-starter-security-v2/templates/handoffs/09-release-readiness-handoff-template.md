# Release Readiness Handoff Template

## Header
- **Feature ID / Release ID:** [ID]
- **Status:** DRAFT
- **Author:** Platform/Release Agent
- **Next Owner:** Main Agent
- **Target environment/date:** [DETAILS]

## Release scope
- [Feature/change]
- [Feature/change]

## Build and deployment status
- [ ] Build succeeded
- [ ] Artifacts versioned
- [ ] Migration plan reviewed
- [ ] Environment config verified
- [ ] Secrets/config changes applied
- [ ] Rollback plan tested or reviewed

## Test evidence summary
- unit/component: [Result/link]
- integration/API: [Result/link]
- E2E/smoke: [Result/link]
- manual verification: [Result/link]

## Change risk assessment
- **Risk level:** [LOW/MEDIUM/HIGH]
- **Why:** [Reason]

## Dependency check
- [Dependency and status]
- [Dependency and status]

## Operational readiness
- monitoring: [Ready/not ready]
- alerts: [Ready/not ready]
- dashboards: [Link]
- runbook: [Link]
- on-call notification: [Who/where]

## Rollout plan
1. [Step]
2. [Step]
3. [Step]

## Rollback plan
1. [Step]
2. [Step]
3. [Step]

## Customer/user impact
- [User-visible change]
- [Support note / release note]
- [Downtime expectation if any]

## Final go/no-go recommendation
- [ ] GO
- [ ] GO WITH CONDITIONS
- [ ] NO-GO

## Conditions or blockers
- [Condition/blocker]
- [Condition/blocker]
