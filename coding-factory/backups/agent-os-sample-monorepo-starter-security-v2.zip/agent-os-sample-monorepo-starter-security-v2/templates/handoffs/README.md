# Feature Handoff Template Set

This pack provides copy/paste Markdown templates for a main agent and specialist sub-agents building production-quality web and mobile apps.

## Recommended use
- Keep one canonical feature thread in Slack.
- Keep the durable version of each artifact in Git or your docs repo.
- Require every handoff to name the **next owner**, **risks**, **tests/evidence**, and **rollback notes**.
- Do not allow an agent to mark work "done" without completed acceptance criteria and attached evidence.

## Included templates
1. `00-handoff-operating-rules.md`
2. `01-main-agent-dispatch-template.md`
3. `02-feature-intake-template.md`
4. `03-feature-brief-template.md`
5. `04-architecture-rfc-handoff-template.md`
6. `05-api-contract-handoff-template.md`
7. `06-web-implementation-handoff-template.md`
8. `07-mobile-implementation-handoff-template.md`
9. `08-qa-test-plan-handoff-template.md`
10. `09-release-readiness-handoff-template.md`
11. `10-post-release-review-template.md`
12. `11-bug-incident-handoff-template.md`

## Suggested flow
Feature Intake → Main Agent Dispatch → Feature Brief → Architecture RFC → API Contract → Web/Mobile Implementation → QA/Test Plan Execution → Release Readiness → Post-Release Review

## Conventions
- Replace all bracketed placeholders like `[FEATURE_ID]`.
- Keep sections even if the answer is "None" or "N/A".
- Prefer links to artifacts over pasted walls of text.
