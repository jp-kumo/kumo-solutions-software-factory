# Feature Brief Template

## Header
- **Feature ID:** [FEATURE_ID]
- **Title:** [TITLE]
- **Status:** DRAFT
- **Author:** [OWNER]
- **Reviewers:** [NAMES]
- **Slack Thread:** [LINK]

## Executive summary
[2–5 sentence summary of the feature and expected user/business outcome.]

## Problem and context
### Problem
[Describe the current pain/problem.]

### Context
[Relevant background, existing systems, constraints, prior decisions.]

## Goals
- [Goal]
- [Goal]

## Non-goals
- [Non-goal]
- [Non-goal]

## Users and scenarios
### Primary user
[Who is the main user?]

### Key scenarios
1. [Scenario]
2. [Scenario]
3. [Scenario]

## Functional requirements
- [Requirement]
- [Requirement]
- [Requirement]

## Non-functional requirements
- Performance: [Requirement]
- Reliability: [Requirement]
- Security/privacy: [Requirement]
- Accessibility: [Requirement]
- Analytics/observability: [Requirement]

## UX notes
- [UI/UX expectation]
- [Edge case]
- [Empty/error/loading state]

## Data and integrations
- [Data source]
- [External system]
- [Sync/offline need if any]

## Acceptance criteria
- [ ] [Criterion]
- [ ] [Criterion]
- [ ] [Criterion]

## Risks and tradeoffs
- [Risk/tradeoff]
- [Risk/tradeoff]

## Open questions
- [Question]
- [Question]

## Ready for architecture when
- [ ] Problem is clearly scoped
- [ ] Acceptance criteria are specific
- [ ] Non-goals are documented
- [ ] Dependencies are listed
