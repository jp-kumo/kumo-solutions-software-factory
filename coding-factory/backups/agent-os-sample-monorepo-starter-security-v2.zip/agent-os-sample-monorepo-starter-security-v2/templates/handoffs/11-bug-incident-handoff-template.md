# Bug / Incident Handoff Template

## Header
- **Issue ID:** [BUG_OR_INCIDENT_ID]
- **Type:** [BUG / INCIDENT / REGRESSION]
- **Severity:** [SEV1/SEV2/SEV3/SEV4]
- **Status:** DRAFT
- **Current Owner:** [OWNER]
- **Next Owner:** [OWNER]
- **Environment:** [DEV/STAGE/PROD]
- **Detected at:** [DATE/TIME]
- **Slack thread/channel:** [LINK]

## Summary
[Concise summary of the issue and user/system impact.]

## Impact
- affected users: [Who/how many]
- affected systems: [What]
- business impact: [Impact]
- workaround available?: [Yes/No + details]

## Reproduction or trigger
### Steps to reproduce
1. [Step]
2. [Step]
3. [Step]

### Actual result
[What happened]

### Expected result
[What should have happened]

## Evidence
- logs: [Link]
- screenshots/video: [Link]
- metrics/traces: [Link]
- related deploy/change: [Link]

## Suspected cause
[Known facts, not guesses if possible.]

## Immediate containment
- [Action]
- [Action]

## Needed from next owner
- [Ask]
- [Ask]

## Decision log
- [Timestamp] [Decision]
- [Timestamp] [Decision]

## Resolution plan
- [Action + owner]
- [Action + owner]

## Close criteria
- [ ] Root cause understood or documented as unknown
- [ ] User impact mitigated
- [ ] Fix verified
- [ ] Follow-up actions assigned
