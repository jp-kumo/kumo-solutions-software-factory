# Web Implementation Handoff Template

## Header
- **Feature ID:** [FEATURE_ID]
- **Status:** DRAFT
- **Author:** Web Agent
- **Next Owner:** [QA / PLATFORM / MAIN AGENT]
- **Related brief:** [LINK]
- **Related contract:** [LINK]

## Scope completed
- [UI/view/component]
- [Form/workflow/state]
- [Routing/navigation]
- [Analytics/observability]

## Files and modules changed
- [Path or module]
- [Path or module]

## UI states covered
- [ ] loading
- [ ] empty
- [ ] success
- [ ] validation error
- [ ] server/API error
- [ ] permission/auth state

## Accessibility checks
- [ ] Keyboard accessible
- [ ] Semantic roles/labels
- [ ] Focus management considered
- [ ] Color contrast/design token usage checked
- [ ] Error messages are clear and associated to inputs

## Performance notes
- [Bundle/code splitting concern]
- [Rendering/data fetching concern]
- [Caching/revalidation note]

## Testing completed
### Unit/component tests
- [Test file/link]
- [Test file/link]

### Integration/E2E notes
- [Flow]
- [Flow]

## Screenshots / evidence
- [Link]
- [Link]

## Known limitations
- [Limitation]
- [Limitation]

## Risks
- [Risk + mitigation]
- [Risk + mitigation]

## Explicit asks to QA / next owner
- [Ask]
- [Ask]

## Ready for next stage when
- [ ] Acceptance criteria implemented
- [ ] Tests added/updated
- [ ] Screenshots attached
- [ ] Known limitations documented
