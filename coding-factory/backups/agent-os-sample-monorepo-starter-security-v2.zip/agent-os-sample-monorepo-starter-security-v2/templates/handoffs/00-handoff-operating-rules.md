# Handoff Operating Rules

## Goal
Create reliable, reviewable, low-ambiguity handoffs between the main agent and specialist sub-agents.

## Non-negotiable rules
1. Every handoff must include a **Task/Feature ID**.
2. Every handoff must identify the **current owner** and the **next owner**.
3. Every handoff must state whether the artifact is **Draft**, **Ready for Review**, **Blocked**, or **Approved**.
4. Every handoff must include:
   - objective
   - inputs
   - assumptions
   - decisions made
   - risks
   - evidence/tests
   - open questions
   - rollback/mitigation notes where applicable
5. No agent may say **done** unless acceptance criteria are checked and evidence is attached.
6. Slack is the control plane; code, tests, and long-lived docs stay in Git/docs.
7. If a dependency is missing, the agent must mark the task **Blocked** with a concrete unblock request.

## Required status values
- `DRAFT`
- `READY_FOR_REVIEW`
- `BLOCKED`
- `APPROVED`
- `CHANGES_REQUESTED`
- `READY_FOR_NEXT_STAGE`
- `CLOSED`

## Required evidence types
- code links
- test results
- screenshots or recordings for UX changes
- API examples or contract diffs for backend changes
- build/deploy logs for release work
- monitoring confirmation for production changes

## Definition of a valid handoff
A handoff is valid only if it includes:
- feature/task ID
- owner
- next owner
- due gate
- acceptance criteria status
- risk summary
- evidence links
- explicit ask from the next owner

## Escalation rule
If an agent cannot proceed within the agreed scope:
- mark the artifact `BLOCKED`
- summarize the blocker in 3 bullets max
- propose 1–3 resolution options
- tag the main agent for a decision
