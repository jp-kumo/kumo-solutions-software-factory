# QA / Test Plan Handoff Template

## Header
- **Feature ID:** [FEATURE_ID]
- **Status:** DRAFT
- **Author:** QA/Test Agent
- **Next Owner:** [MAIN AGENT / PLATFORM / RELEASE]
- **Related brief:** [LINK]
- **Related implementation handoffs:** [LINKS]

## Test strategy summary
[Summarize test scope and risk posture in 1–2 paragraphs.]

## Risk-based test focus
### Highest-risk areas
- [Area + why]
- [Area + why]

### Lower-risk areas
- [Area + why]
- [Area + why]

## Test matrix
| Area | Unit | Integration | E2E | Manual exploratory | Notes |
|---|---|---|---|---|---|
| [Area] | [Y/N] | [Y/N] | [Y/N] | [Y/N] | [Notes] |
| [Area] | [Y/N] | [Y/N] | [Y/N] | [Y/N] | [Notes] |

## Core scenarios
1. [Scenario]
2. [Scenario]
3. [Scenario]

## Negative/error scenarios
- [Scenario]
- [Scenario]

## Environment and test data
- **Environment:** [DEV/STAGE/PREVIEW]
- **Accounts/data fixtures:** [Details]
- **External dependencies mocked?:** [Yes/No + details]

## Accessibility / usability checks
- [Check]
- [Check]

## Security / abuse-case checks
- [Check]
- [Check]

## Regression scope
- [Area]
- [Area]

## Exit criteria
- [ ] No open P0/P1 defects
- [ ] Acceptance criteria verified
- [ ] Critical path E2E passes
- [ ] Known issues documented and accepted

## Defects / observations
- [Defect ID + summary]
- [Defect ID + summary]

## Release recommendation
- [ ] Approve for release
- [ ] Approve with known issues
- [ ] Do not release

## Notes to next owner
[Explicit recommendation or blocker summary]
