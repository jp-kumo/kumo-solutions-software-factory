#!/usr/bin/env bash
set -euo pipefail

echo "==> Starting local Postgres"
docker compose -f infra/local/docker-compose.yml up -d

echo "==> Starter repo is ready for web, mobile, and API setup"
echo "Run web:    pnpm --dir apps/web install && pnpm --dir apps/web dev"
echo "Run mobile: pnpm --dir apps/mobile install && pnpm --dir apps/mobile start"
echo "Run api:    cd services/api && ./gradlew bootRun"
