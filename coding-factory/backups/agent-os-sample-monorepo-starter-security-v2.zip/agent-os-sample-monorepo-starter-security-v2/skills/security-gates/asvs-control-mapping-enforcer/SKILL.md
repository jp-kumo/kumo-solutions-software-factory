---
name: asvs-control-mapping-enforcer
version: 1.0.0
description: Maps applicable OWASP ASVS 5.0.0 controls to implementation and verification evidence for web apps and backend services.
metadata:
  openclaw:
    emoji: "📋"
---

# ASVS Control Mapping Enforcer

Use this skill to convert a feature, service, or release into an evidence-based OWASP ASVS 5.0.0 control mapping.

## Mission

Create a practical verification map, not a fake certification claim.

Your job is to:
- identify which ASVS controls are applicable
- map evidence to those controls
- identify missing verification
- highlight controls that remain unimplemented or unverified
- make release impact explicit

## Scope

Use this for:
- web applications
- backend services
- admin tools
- authentication systems
- sensitive-data workflows
- major release candidates

## Required output structure

Create a control map table or section with:
- control area or control ID
- applicability: required / not required / deferred
- implementation evidence
- verification evidence
- status: pass / partial / fail / unknown
- remediation needed
- owner
- deadline or required stage

## Review rules

- Be selective but defensible: map applicable controls, do not dump the whole standard.
- Unknown evidence is not a pass.
- “Planned” is not the same as implemented.
- “Implemented” is not the same as verified.
- If a release lacks evidence for important applicable controls, call it out as a blocker or conditional risk.

## Minimum domains to consider

At minimum, consider control areas relevant to:
- architecture and threat modeling
- authentication
- access control
- input validation / output handling
- cryptography and secrets
- error handling / logging
- API protections
- file / data handling
- configuration / deployment
- business logic abuse
- data protection and privacy-related safeguards when applicable

## Output template

### ASVS Mapping
For each applicable area/control:
- **Control Area / ID:**
- **Why It Applies:**
- **Implementation Evidence:**
- **Verification Evidence:**
- **Status:** PASS / PARTIAL / FAIL / UNKNOWN
- **Gap / Remediation:**
- **Owner:**
- **Required By Stage:**

Then end with:
- **ASVS Coverage Summary:**
- **Highest-Risk Unmet Controls:**
- **Decision:** GO / CONDITIONAL GO / NO-GO
- **Ready for Next Stage:** YES / NO

