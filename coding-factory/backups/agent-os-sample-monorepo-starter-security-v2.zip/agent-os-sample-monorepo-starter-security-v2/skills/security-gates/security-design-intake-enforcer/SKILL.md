---
name: security-design-intake-enforcer
version: 1.0.0
description: Forces security-relevant scope, data sensitivity, trust boundaries, and downstream gate requirements into feature intake before architecture begins.
metadata:
  openclaw:
    emoji: "🧭"
---

# Security Design Intake Enforcer

Use this skill at project intake or feature intake to force security-relevant context into scope before architecture and implementation begin.

## Required inputs

You should look for:
- feature summary
- users / actors
- data types handled
- platforms affected: web, mobile, backend, admin tools, integrations
- auth expectations
- external services and dependencies
- environment assumptions
- business criticality
- regulated, contractual, or customer security needs

If any of those are missing, call them out as intake gaps.

## Required output

Produce a structured intake security artifact with:

1. Security scope
2. Data sensitivity classification
3. Trust boundaries
4. Authentication / authorization expectations
5. High-risk operations
6. External dependency risk
7. Initial abuse cases
8. Required downstream security gates
9. Intake blockers
10. Decision: GO / NO-GO for architecture

## Security-by-design rules

Always require explicit treatment of:
- secrets
- sensitive data
- privileged actions
- administrative surfaces
- background jobs
- third-party integrations
- public endpoints
- device/platform permissions for mobile
- outbound API calls

Do not allow “we will secure it later” language to pass as sufficient.

## Default guidance to include

Recommend these baselines by default:
- OWASP Top 10:2025 for web risk awareness
- ASVS 5.0.0 for app/backend verification mapping
- API Security Top 10 2023 for APIs
- MASVS for mobile apps
- SSDF 1.1 for secure SDLC expectations

## Output template

### Security Intake Review
- **Feature / Project:**
- **Platforms in Scope:**
- **Data Sensitivity:**
- **Trust Boundaries:**
- **High-Risk Operations:**
- **External Dependencies / Services:**
- **Initial Abuse Cases:**
- **Required Security Gates:**
- **Missing Intake Information:**
- **Decision:** GO / NO-GO
- **Ready for Architecture:** YES / NO

