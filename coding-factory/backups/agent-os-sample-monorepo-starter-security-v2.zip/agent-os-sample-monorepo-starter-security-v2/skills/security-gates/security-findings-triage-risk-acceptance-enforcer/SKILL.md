---
name: security-findings-triage-risk-acceptance-enforcer
version: 1.0.0
description: Forces security findings into explicit dispositions, owners, risk acceptance decisions, and release-impact outcomes.
metadata:
  openclaw:
    emoji: "🚨"
---

# Security Findings Triage and Risk Acceptance Enforcer

Use this skill whenever security findings exist and the team needs a disciplined disposition process before release or stage advancement.

## Mission

Turn a pile of findings into a governed decision.

Do not allow findings to remain as vague backlog items. Every finding must have:
- severity
- business impact
- exploitability or abuse rationale
- owner
- disposition
- due stage/date
- release effect

## Allowed dispositions

Use only these dispositions:
1. Fix before next stage
2. Fix before release
3. Mitigate with compensating control
4. Temporarily accept risk
5. False positive / not applicable

## Rules for risk acceptance

Temporary risk acceptance requires:
- explicit statement of the risk
- reason remediation is not complete
- impact scope
- compensating controls if any
- named approver with authority
- expiration or review date
- follow-up owner

Do not accept risk silently.

## Blocking rules

- Critical findings are presumptive NO-GO.
- High findings require strong evidence to become anything other than release blockers.
- Unknown severity is not acceptable for release-critical scope.
- Findings without owners are not considered managed.
- Findings without review date are not considered accepted.

## Output template

### Security Findings Triage
For each finding:
- **Finding ID:**
- **Title:**
- **Severity:**
- **Affected Area:**
- **Standard Mapping:**
- **Impact / Exploitability:**
- **Disposition:**
- **Owner:**
- **Required By:**
- **Approver if Risk Accepted:**
- **Notes / Compensating Controls:**

Then end with:
- **Unresolved Blocking Findings:**
- **Accepted Risks:**
- **Recommended Decision:** GO / CONDITIONAL GO / NO-GO
- **Ready for Release Gate:** YES / NO

