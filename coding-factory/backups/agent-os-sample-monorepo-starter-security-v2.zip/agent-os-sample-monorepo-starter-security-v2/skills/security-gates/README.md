# Security Gate Skill Pack

This pack contains OpenClaw-ready skills that enforce security-by-design gates across your Coding Factory.

## Contents

1. `security-gate-orchestrator`
2. `security-design-intake-enforcer`
3. `threat-model-abuse-case-enforcer`
4. `owasp-top10-2025-review-enforcer`
5. `asvs-control-mapping-enforcer`
6. `api-top10-2023-review-enforcer`
7. `masvs-mobile-review-enforcer`
8. `security-findings-triage-risk-acceptance-enforcer`
9. `security-release-gatekeeper`

## Recommended usage order

- intake -> `security-design-intake-enforcer`
- architecture -> `threat-model-abuse-case-enforcer`
- web/backend review -> `owasp-top10-2025-review-enforcer`
- app/backend verification map -> `asvs-control-mapping-enforcer`
- API review -> `api-top10-2023-review-enforcer`
- mobile review -> `masvs-mobile-review-enforcer`
- findings disposition -> `security-findings-triage-risk-acceptance-enforcer`
- release -> `security-release-gatekeeper`

Use `security-gate-orchestrator` when the main agent or Security/Compliance Agent needs to decide which security gate should run next.

## Notes

- These skills are designed to force structured security artifacts.
- They are intentionally conservative about release decisions.
- They are best used alongside your master orchestrator skill, the handoff-enforcement skills, and the Security/Compliance Agent prompt.
