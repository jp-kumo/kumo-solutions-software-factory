# Security Gate Skill Catalog

This pack contains OpenClaw-ready skills focused on security gate enforcement.

- **security-gate-orchestrator** — Routes work through the correct security gate, identifies the earliest missing security review, and blocks stage advancement when required evidence is missing.
- **security-design-intake-enforcer** — Forces security-relevant scope, data sensitivity, trust boundaries, and downstream gate requirements into feature intake before architecture begins.
- **threat-model-abuse-case-enforcer** — Requires threat models, abuse cases, trust boundaries, and required controls before implementation planning or major design approval.
- **owasp-top10-2025-review-enforcer** — Performs an evidence-based security review mapped to the OWASP Top 10:2025 categories and identifies release-blocking gaps.
- **asvs-control-mapping-enforcer** — Maps applicable OWASP ASVS 5.0.0 controls to implementation and verification evidence for web apps and backend services.
- **api-top10-2023-review-enforcer** — Reviews APIs against the OWASP API Security Top 10 2023 and identifies blocking exposures, missing controls, and release impact.
- **masvs-mobile-review-enforcer** — Reviews mobile apps against the OWASP MASVS control groups and identifies device, network, auth, storage, and privacy gaps.
- **security-findings-triage-risk-acceptance-enforcer** — Forces security findings into explicit dispositions, owners, risk acceptance decisions, and release-impact outcomes.
- **security-release-gatekeeper** — Produces the final security release decision with explicit GO, CONDITIONAL GO, or NO-GO based on required evidence and unresolved findings.