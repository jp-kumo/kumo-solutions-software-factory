---
name: security-release-gatekeeper
version: 1.0.0
description: Produces the final security release decision with explicit GO, CONDITIONAL GO, or NO-GO based on required evidence and unresolved findings.
metadata:
  openclaw:
    emoji: "⛔"
---

# Security Release Gatekeeper

Use this skill at release readiness, production launch approval, or high-risk change approval.

## Mission

Provide the final security recommendation for release:
- GO
- CONDITIONAL GO
- NO-GO

This skill should consume all prior security artifacts, not replace them.

## Required inputs

Expect evidence from:
- intake security review
- threat model / abuse cases
- OWASP Top 10:2025 review
- ASVS control mapping
- API Top 10 review if APIs exist
- MASVS review if mobile exists
- findings triage / risk acceptance
- release notes / rollback notes
- monitoring / alerting readiness

If required evidence is missing, say so and block release.

## Release blocking checks

At minimum, verify:
- access-control model is reviewed
- auth/session/token risk is reviewed
- secrets handling is acceptable
- crypto-sensitive flows are reviewed
- major API exposures are reviewed
- mobile-specific controls are reviewed when applicable
- logging/alerting support investigation
- supply-chain and build/release protections are not obviously deficient
- unresolved critical/high findings are dispositioned appropriately
- accepted risks are explicit and authorized

## Decision logic

### GO
Use only when:
- required security gates completed
- no unresolved release-blocking findings remain
- remaining lower-severity items are owned and scheduled

### CONDITIONAL GO
Use when:
- residual risk exists but is explicitly documented
- the correct authority accepted it
- compensating controls and dates exist
- monitoring is sufficient for near-term detection

### NO-GO
Use when:
- required evidence is missing
- critical or high findings remain unresolved
- major uncertainty remains around access control, identity, secrets, integrity, sensitive data, or mobile/API exposure
- release pressure is overriding security process

## Output template

### Security Release Decision
- **Release Candidate / Scope:**
- **Evidence Reviewed:**
- **Blocking Findings:**
- **Accepted Risks:**
- **Required Compensating Controls:**
- **Monitoring / Alerting Readiness:**
- **Rollback Readiness:**
- **Decision:** GO / CONDITIONAL GO / NO-GO
- **Reasoning:**
- **Follow-Up Actions:**
- **Ready to Release:** YES / NO

