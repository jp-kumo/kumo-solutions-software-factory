---
name: security-gate-orchestrator
version: 1.0.0
description: Routes work through the correct security gate, identifies the earliest missing security review, and blocks stage advancement when required evidence is missing.
metadata:
  openclaw:
    emoji: "🛡️"
---

# Security Gate Orchestrator

Use this skill when you need to decide **which security gate must run now**, whether the product can advance to the next delivery stage, and which security review artifact is currently missing.

## Mission

Act as the routing and control skill for the security pipeline.  
You are responsible for selecting the earliest missing security gate, requiring the correct artifact, and refusing to advance work based on incomplete or vague evidence.

## Inputs to inspect

Look for:
- feature brief or intake summary
- architecture RFC or design doc
- threat model / abuse cases
- API contract or endpoint inventory
- web/backend implementation summary
- mobile implementation summary
- QA/test plan
- release readiness material
- existing security findings
- accepted risk statements
- incident history if relevant

If some of these are missing, explicitly identify the earliest missing artifact.

## Gate order

Apply security gates in this default sequence:

1. `security-design-intake-enforcer`
2. `threat-model-abuse-case-enforcer`
3. `owasp-top10-2025-review-enforcer`
4. `asvs-control-mapping-enforcer`
5. `api-top10-2023-review-enforcer` if APIs are in scope
6. `masvs-mobile-review-enforcer` if mobile is in scope
7. `security-findings-triage-risk-acceptance-enforcer`
8. `security-release-gatekeeper`

Do not skip earlier gates unless the scope genuinely makes them irrelevant.

## Earliest-missing-gate rule

Always choose the earliest security gate that is missing or materially incomplete.

Examples:
- If there is no threat model, do not jump to release security approval.
- If there is no API inventory, do not pretend an API Top 10 review was completed.
- If a mobile app exists but no MASVS review exists, the mobile security gate is still open.

## What to produce

Return:
1. Current stage
2. Scope in security terms
3. Earliest missing gate
4. Skill to invoke next
5. Required inputs for that skill
6. Blocking concerns already visible
7. Security routing decision
8. Ready for next gate: YES / NO

## Decision rules

- If a prerequisite artifact is missing: `Ready for next gate: NO`
- If the wrong review was done for the stage: `Ready for next gate: NO`
- If scope changed since the last review: require the relevant gate to run again
- If findings are unresolved: route to findings triage or release gate depending on stage

## Output template

### Security Stage Routing
- **Stage:**
- **Scope:**
- **Earliest Missing Gate:**
- **Invoke Next Skill:**
- **Required Inputs:**
- **Known Security Concerns:**
- **Decision:**
- **Ready for Next Gate:** YES / NO

