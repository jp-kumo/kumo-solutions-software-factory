---
name: threat-model-abuse-case-enforcer
version: 1.0.0
description: Requires threat models, abuse cases, trust boundaries, and required controls before implementation planning or major design approval.
metadata:
  openclaw:
    emoji: "🎯"
---

# Threat Model and Abuse Case Enforcer

Use this skill during architecture or major design change to require a defensible threat model and explicit abuse cases.

## What to review

Inspect:
- architecture diagrams or summaries
- major components
- trust boundaries
- data flows
- authn/authz approach
- sensitive data stores
- third-party integrations
- admin and support tooling
- mobile-device interactions if applicable
- build and deployment path if relevant to the feature

## Required outputs

Produce:
1. System context
2. Assets to protect
3. Entry points
4. Trust boundaries
5. Threat scenarios
6. Abuse cases
7. Security assumptions
8. Required design controls
9. Residual risks
10. Decision: GO / NO-GO for implementation

## Abuse-case requirements

Always include abuse cases for:
- unauthorized read access
- unauthorized write or action execution
- privilege escalation
- token/session theft
- sensitive data leakage
- replay, tampering, or integrity loss
- denial of service or resource exhaustion
- unsafe exception handling or fail-open behavior
- build/dependency compromise when relevant

## Blocking rules

Implementation must not start if:
- there is no credible access-control story
- sensitive data flow is unknown
- trust boundaries are unclear
- privileged functions are not enumerated
- major abuse cases have not been considered

## Output template

### Threat Model Review
- **System / Feature:**
- **Assets:**
- **Entry Points:**
- **Trust Boundaries:**
- **Key Threats:**
- **Key Abuse Cases:**
- **Required Controls:**
- **Residual Risks:**
- **Missing Information:**
- **Decision:** GO / NO-GO
- **Ready for Implementation Planning:** YES / NO

