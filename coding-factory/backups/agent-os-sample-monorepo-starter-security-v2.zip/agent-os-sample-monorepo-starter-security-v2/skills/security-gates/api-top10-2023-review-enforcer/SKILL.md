---
name: api-top10-2023-review-enforcer
version: 1.0.0
description: Reviews APIs against the OWASP API Security Top 10 2023 and identifies blocking exposures, missing controls, and release impact.
metadata:
  openclaw:
    emoji: "🔌"
---

# API Top 10 2023 Review Enforcer

Use this skill for any API, backend-for-frontend, service endpoint set, webhook surface, or machine-to-machine interface.

## Review against these categories

1. Broken Object Level Authorization
2. Broken Authentication
3. Broken Object Property Level Authorization
4. Unrestricted Resource Consumption
5. Broken Function Level Authorization
6. Unrestricted Access to Sensitive Business Flows
7. Server Side Request Forgery
8. Security Misconfiguration
9. Improper Inventory Management
10. Unsafe Consumption of APIs

## Required evidence

Review should use:
- endpoint inventory
- auth scheme
- object identifiers and tenancy model
- function/action list
- input/output examples
- rate limits and quotas
- admin/internal/public exposure
- outbound dependency behavior
- logging and monitoring
- deprecation and versioning posture

## Required output

For each category provide:
- applicability
- affected endpoints or flows
- controls present
- gaps
- severity
- owner
- release impact

## Blocking rules

Treat these as presumptive blockers unless clearly addressed:
- missing object-level authorization checks
- weak or ambiguous service-to-service auth
- unrestricted high-cost operations
- unbounded or weakly controlled sensitive business actions
- no usable API inventory for the release
- unsafe outbound API trust assumptions with no validation or containment

## Output template

### API Security Review
For each API Top 10 category:
- **Category:**
- **In Scope:** YES / NO
- **Affected Endpoints / Flows:**
- **Controls Present:**
- **Findings / Gaps:**
- **Severity:**
- **Owner:**
- **Release Impact:**

Then end with:
- **API Security Summary:**
- **Blocking API Findings:**
- **Decision:** GO / CONDITIONAL GO / NO-GO
- **Ready for Next Stage:** YES / NO

