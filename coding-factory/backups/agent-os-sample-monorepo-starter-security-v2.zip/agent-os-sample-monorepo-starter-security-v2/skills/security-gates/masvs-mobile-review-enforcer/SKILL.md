---
name: masvs-mobile-review-enforcer
version: 1.0.0
description: Reviews mobile apps against the OWASP MASVS control groups and identifies device, network, auth, storage, and privacy gaps.
metadata:
  openclaw:
    emoji: "📱"
---

# MASVS Mobile Review Enforcer

Use this skill for mobile applications, mobile SDKs, or mobile features that handle sensitive data, authentication, device permissions, or privileged platform interactions.

## Review baseline

Review the app against the relevant OWASP MASVS control groups.

At minimum, assess:
- MASVS-STORAGE
- MASVS-CRYPTO
- MASVS-AUTH
- MASVS-NETWORK
- MASVS-PLATFORM
- MASVS-CODE
- MASVS-RESILIENCE when appropriate
- MASVS-PRIVACY when applicable

## What to inspect

Look for:
- local storage of sensitive values
- keychain / keystore usage
- token handling and session lifecycle
- transport protections and certificate handling assumptions
- deep links / intents / app links / URL handlers
- permissions
- clipboard, screenshots, caching, and local logs
- update and dependency hygiene
- anti-tamper / anti-abuse measures if required by threat model
- privacy disclosures and data minimization where relevant

## Output requirements

For each control group:
- applicability
- evidence reviewed
- controls present
- gaps
- severity
- owner
- required stage for remediation

## Blocking rules

Flag as blocker if any of the following are present without adequate treatment:
- secrets or long-lived credentials embedded in app code or bundles
- sensitive data stored insecurely on device
- unsafe token/session persistence
- broken transport assumptions or easy MITM risk
- risky platform exposure with no constraints
- critical privacy-sensitive flows with no protective controls

## Output template

### MASVS Review
For each control group:
- **Group:**
- **In Scope:** YES / NO
- **Evidence Reviewed:**
- **Controls Present:**
- **Findings / Gaps:**
- **Severity:**
- **Owner:**
- **Required By Stage:**

Then end with:
- **Mobile Security Summary:**
- **Blocking Mobile Findings:**
- **Decision:** GO / CONDITIONAL GO / NO-GO
- **Ready for Next Stage:** YES / NO

