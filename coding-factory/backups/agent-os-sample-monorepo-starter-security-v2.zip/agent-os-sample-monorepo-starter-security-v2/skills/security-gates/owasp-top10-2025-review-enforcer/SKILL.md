---
name: owasp-top10-2025-review-enforcer
version: 1.0.0
description: Performs an evidence-based security review mapped to the OWASP Top 10:2025 categories and identifies release-blocking gaps.
metadata:
  openclaw:
    emoji: "🔟"
---

# OWASP Top 10:2025 Review Enforcer

Use this skill to perform a web-application / general application security review mapped to the OWASP Top 10:2025 categories.

## Review objective

Assess the feature, service, or application against the OWASP Top 10:2025 categories and identify:
- risks present
- controls already implemented
- gaps
- remediation actions
- release impact

## Categories to review

Review all of these categories unless truly out of scope:

1. Broken Access Control
2. Security Misconfiguration
3. Software Supply Chain Failures
4. Cryptographic Failures
5. Injection
6. Insecure Design
7. Authentication Failures
8. Software or Data Integrity Failures
9. Security Logging and Alerting Failures
10. Mishandling of Exceptional Conditions

## Review method

For each category:
- decide whether it is in scope
- note evidence of exposure or control
- record gaps
- name the owner
- classify release impact

Do not merely restate category names. Apply them to the actual feature.

## Examples of what to look for

- Access control on objects, actions, and tenancy boundaries
- Config drift, dangerous defaults, exposed debug/admin functions
- Dependency hygiene, lockfiles, CI/CD protections, package trust
- Key management, crypto misuse, weak transport assumptions
- Injection paths through inputs, templates, queries, logs, shell, or deserialization
- Design-level missing controls, not just coding mistakes
- Session, token, and login flows
- Integrity of updates, artifacts, events, and mutable business data
- Detectability and investigation support
- Safe failure behavior, retries, fallbacks, and boundary conditions

## Output template

### OWASP Top 10:2025 Review
For each category include:
- **Category:**
- **In Scope:** YES / NO
- **Evidence Reviewed:**
- **Controls Present:**
- **Gaps / Findings:**
- **Severity:**
- **Owner:**
- **Release Impact:**

Then end with:
- **Overall Security Summary:**
- **Blocking Findings:**
- **Decision:** GO / CONDITIONAL GO / NO-GO
- **Ready for Next Stage:** YES / NO

