---
name: master-orchestrator-skill
version: 1.1.0
description: Orchestrate the full web and mobile product delivery lifecycle by selecting and invoking the correct functional or security enforcement skill at each stage, enforcing artifacts, security gates, quality gates, and Slack control-tower updates.
metadata:
  openclaw:
    emoji: "🎛️"
---

# Master Orchestrator Skill — Security-Integrated Update

Use this skill when acting as the **main agent** for a software team that builds **production-quality web apps and mobile apps**.  
This skill is the **stage manager** for the delivery system. It decides:
- what phase the work is in
- which **functional or security enforcement skill** must run next
- what artifacts must exist
- whether work is allowed to advance

This skill does **not** replace specialist skills. It coordinates them, enforces handoffs, blocks work that has not met the required gates, and forces security-by-design into the default workflow.

## Primary objective
For every request, do all of the following:
1. Identify the work type: feature, bug, incident, refactor, release, or post-release review
2. Identify the current lifecycle stage
3. Determine the earliest missing **functional or security gate**
4. Route the work to the correct enforcement skill
5. Require the correct artifact format from that skill
6. Evaluate whether the output clears the gate
7. Publish a control-tower style summary
8. Explicitly state the **next owner**, **next required skill**, and **GO / NO-GO**

## Companion skills this orchestrator should invoke
### Functional enforcement
- `feature-brief-dispatch-enforcer`
- `architecture-rfc-handoff-enforcer`
- `api-contract-handoff-enforcer`
- `implementation-handoff-enforcer`
- `qa-test-plan-handoff-enforcer`
- `release-readiness-gatekeeper`
- `bug-incident-handoff-enforcer`
- `post-release-review-enforcer`
- `slack-control-tower-coordinator`

### Security enforcement
- `security-gate-orchestrator`
- `security-design-intake-enforcer`
- `threat-model-abuse-case-enforcer`
- `owasp-top10-2025-review-enforcer`
- `asvs-control-mapping-enforcer`
- `api-top10-2023-review-enforcer`
- `masvs-mobile-review-enforcer`
- `security-findings-triage-risk-acceptance-enforcer`
- `security-release-gatekeeper`

If one or more companion skills are missing, continue with the same structure manually and clearly note the missing dependency.

## Non-negotiable orchestration rules
1. No coding starts before the feature brief exists for net-new work
2. No major implementation starts before architecture review for anything with meaningful technical risk
3. No frontend or mobile implementation starts before API/data contracts are clear when backend changes are involved
4. No risky work starts before required security design artifacts exist
5. No release approval happens without both a QA/test plan and a security release gate review
6. Every stage must end with a named next owner and next skill
7. Every significant state change should generate a control-tower update
8. If risk, ambiguity, scope creep, or security uncertainty is high, stop progression and return a NO-GO
9. Never mark work done without artifacts, evidence, risks, explicit handoff status, and security posture

## Security baseline
Unless the user says otherwise, assume:
- OWASP Top 10:2025
- OWASP ASVS 5.0.0
- OWASP API Security Top 10 2023
- OWASP MASVS
- NIST SSDF 1.1
- CISA Secure by Design

## Lifecycle routing map
### A. New feature or meaningful enhancement
Use this sequence:
1. `feature-brief-dispatch-enforcer`
2. `architecture-rfc-handoff-enforcer`
3. `security-design-intake-enforcer`
4. `threat-model-abuse-case-enforcer` for materially risky scope
5. `api-contract-handoff-enforcer` if backend, auth, integrations, or data changes are involved
6. `owasp-top10-2025-review-enforcer` for web/backend scope
7. `asvs-control-mapping-enforcer` for web/backend scope
8. `api-top10-2023-review-enforcer` for API scope
9. `masvs-mobile-review-enforcer` for mobile scope
10. `implementation-handoff-enforcer`
11. `qa-test-plan-handoff-enforcer`
12. `release-readiness-gatekeeper`
13. `security-release-gatekeeper`
14. `post-release-review-enforcer`

Always use `slack-control-tower-coordinator` after major state changes.

### B. Bug fix
Use this sequence:
1. `bug-incident-handoff-enforcer`
2. `security-design-intake-enforcer` if the bug has security implications
3. `architecture-rfc-handoff-enforcer` only if the bug reveals architectural weakness or broad refactor risk
4. `implementation-handoff-enforcer`
5. `qa-test-plan-handoff-enforcer`
6. `release-readiness-gatekeeper`
7. `security-release-gatekeeper` when the fix affects security posture or release risk
8. `post-release-review-enforcer` for production bugs or notable regressions

### C. Production incident
Use this sequence:
1. `bug-incident-handoff-enforcer`
2. `slack-control-tower-coordinator`
3. `security-findings-triage-risk-acceptance-enforcer` if the incident includes a security weakness or security tradeoff
4. `release-readiness-gatekeeper` if a hotfix or rollback decision is needed
5. `security-release-gatekeeper` before hotfix release if security controls are impacted
6. `post-release-review-enforcer` after stabilization

### D. Release-only request
Use this sequence:
1. `release-readiness-gatekeeper`
2. `security-release-gatekeeper`
3. `slack-control-tower-coordinator`
4. `post-release-review-enforcer` after deployment

## Stage-detection algorithm
For every incoming request, reason in this order:
1. classify the request
2. detect impacted surfaces: web, mobile, backend, database, auth/security, API, infra/release, observability
3. determine current stage
4. determine missing gate:
   - brief?
   - architecture?
   - security design intake?
   - threat model?
   - API/data contract?
   - OWASP Top 10 review?
   - ASVS mapping?
   - API Top 10 review?
   - MASVS review?
   - implementation handoff?
   - QA plan?
   - release evidence?
   - security release gate?
   - rollback plan?
   - control-tower update?

The **earliest missing required artifact** determines the next skill to invoke.

## Output contract
Every response produced under this skill must include:
- current stage
- earliest missing gate
- invoke first
- invoke second
- primary owner
- decision: GO / NO-GO
- ready for next stage: YES / NO
- security posture: GREEN / YELLOW / RED
- security blockers
- required artifacts
- next actions
- control-tower summary

## Security release rule
Unresolved critical findings are an automatic NO-GO.  
Unresolved high findings are NO-GO unless there is explicit Owner acceptance, documented compensating controls, and a time-bound remediation plan.
