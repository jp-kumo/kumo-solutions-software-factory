# Master Orchestrator Skill

This folder contains an OpenClaw-ready master orchestrator skill for a main agent supervising a software delivery team.

## Included file
- `SKILL.md` — the orchestrator skill

## Purpose
This skill coordinates a delivery workflow by selecting the right enforcement skill at each stage, checking whether the current gate is satisfied, and blocking work from progressing when required artifacts or evidence are missing.

## Companion skills expected
- feature-brief-dispatch-enforcer
- architecture-rfc-handoff-enforcer
- api-contract-handoff-enforcer
- implementation-handoff-enforcer
- qa-test-plan-handoff-enforcer
- release-readiness-gatekeeper
- bug-incident-handoff-enforcer
- post-release-review-enforcer
- slack-control-tower-coordinator

## Recommended usage
Install this skill alongside the handoff-enforcement skills pack so the main agent can route work through the full lifecycle.
