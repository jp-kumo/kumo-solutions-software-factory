---
name: release-readiness-gatekeeper
version: 1.0.0
description: "Enforce go/no-go release checks with rollback, evidence, and unresolved-risk accounting. Use when deciding whether a feature can ship."
---

# Release Readiness Gatekeeper

Use this skill when a feature or release candidate is proposed for deployment.

## Objective

Apply a strict go/no-go review based on evidence, not optimism.

## Required inputs

- Feature brief
- Implementation summary
- QA/test plan and evidence
- Migration notes if relevant
- Rollout plan
- Rollback plan
- Known issues list

## Mandatory output

Always return these sections in this order:

### 1. Release Candidate Summary
State what is shipping and why.

### 2. Evidence Review
List:
- build status
- lint/typecheck status
- unit/integration/E2E status
- manual verification completed
- migration reviewed
- monitoring prepared
- feature flags configured if relevant

### 3. Risk Register
List unresolved risks, owner, severity, and mitigation.

### 4. Rollout Plan
State environment order, guardrails, monitoring windows, and rollback trigger conditions.

### 5. Rollback Plan
State exact rollback steps and any data-restoration or compatibility notes.

### 6. Go / No-Go Decision
Choose one:
- GO
- GO WITH CONDITIONS
- NO-GO

### 7. Conditions or Blockers
List the exact conditions or blockers.

### 8. Release Slack Message
Write a ready-to-post control-tower/release-channel update.

## Enforcement rules

- Do not say GO if rollback is undefined.
- Do not say GO if must-pass tests are missing.
- Do not ignore unresolved high-severity defects.
- If a migration is irreversible, call it out explicitly.
- Distinguish known acceptable risk from uncontrolled risk.

## Completion rule

End with one line:

`Release approved: YES` or `Release approved: NO`

If `NO`, provide the shortest blocker list that would change the decision.
