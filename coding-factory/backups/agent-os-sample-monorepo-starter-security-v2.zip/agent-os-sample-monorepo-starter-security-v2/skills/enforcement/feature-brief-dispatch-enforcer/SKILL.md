---
name: feature-brief-dispatch-enforcer
version: 1.0.0
description: "Force structured feature briefs and dispatch handoffs for the main agent. Use when converting requests into scoped work with acceptance criteria, dependencies, and next-owner assignments."
---

# Feature Brief + Dispatch Enforcer

Use this skill when the main agent receives a new feature request, enhancement, bugfix request, or exploratory build request.

## Objective

Transform raw input into a **complete feature brief** and a **dispatch handoff** that downstream sub-agents can execute without guessing.

## Required inputs

- Problem statement or request
- Target platform: web, mobile, backend, or multi-surface
- Business goal or user outcome
- Known constraints
- Any explicit deadlines or sequencing constraints

If any required input is missing, make a best effort using stated assumptions. Do not stop at questions unless the missing information creates a critical contradiction.

## Mandatory output

Always return these sections in this order:

### 1. Feature ID
Use a stable identifier such as `FEAT-YYYYMMDD-short-name`.

### 2. Objective
One paragraph describing the business and user goal.

### 3. Scope
- In scope
- Out of scope
- Constraints
- Assumptions

### 4. User Stories
List primary user stories in `As a / I want / so that` form.

### 5. Acceptance Criteria
Use numbered, testable, binary criteria.

### 6. Dependencies
List upstream and downstream dependencies.

### 7. Risks
List delivery, security, compliance, performance, and data risks.

### 8. Required Artifacts
Specify which downstream artifacts must be produced next:
- architecture RFC
- API contract
- implementation plan
- QA test plan
- release checklist
Only include the ones needed for this feature.

### 9. Dispatch Plan
List the next owners in order, for example:
1. Architect Agent
2. API/Data Agent
3. Web Agent
4. QA/Test Agent

### 10. Slack Dispatch Message
Write a ready-to-post Slack message for the control-tower channel with:
- feature ID
- owner
- goal
- due gate
- blockers
- next required artifact

## Enforcement rules

- Do not mark work ready for implementation unless acceptance criteria are specific and testable.
- Do not leave platform ambiguity unresolved; choose web, mobile, backend, or multi-surface explicitly.
- Do not omit out-of-scope items.
- Do not assign coding work before identifying the next required artifact.
- If the feature affects production behavior, include rollout and rollback notes at least at a placeholder level.

## Completion rule

End with one line:

`Ready for architecture handoff: YES` or `Ready for architecture handoff: NO`

If `NO`, list the exact blocking gaps.
