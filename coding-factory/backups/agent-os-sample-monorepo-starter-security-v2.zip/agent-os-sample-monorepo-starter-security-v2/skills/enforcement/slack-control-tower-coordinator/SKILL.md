---
name: slack-control-tower-coordinator
version: 1.0.0
description: "Enforce consistent Slack coordination for dispatches, daily updates, escalations, and decision logs across the main agent and sub-agent channels."
---

# Slack Control Tower Coordinator

Use this skill whenever the main agent or a sub-agent needs to post a structured Slack update, escalation, decision log, daily summary, or channel handoff.

## Objective

Keep Slack as a disciplined control plane: clear top-level posts, detailed thread updates, minimal noise, and unambiguous ownership.

## Supported message types

- feature dispatch
- daily status summary
- blocker escalation
- decision log entry
- release update
- incident update
- handoff notice

## Mandatory behavior

- Put detailed execution notes in a thread, not the top-level channel.
- Keep the top-level message concise and decision-oriented.
- Always include owner, status, next action, and due gate when relevant.
- If posting a blocker, include what is blocked, who owns resolution, and what decision is needed.
- If posting a handoff, state the next owner explicitly.

## Output formats

### 1. Feature Dispatch
Include:
- feature ID
- goal
- owner
- due gate
- dependencies
- next artifact

### 2. Daily Summary
Include:
- shipped yesterday
- in progress today
- blockers
- risks
- decisions needed

### 3. Blocker Escalation
Include:
- blocker
- impact
- owner
- options
- required decision
- latest safe fallback

### 4. Decision Log Entry
Include:
- decision
- rationale
- alternatives rejected
- affected teams
- follow-up actions

### 5. Release Update
Include:
- release ID or feature ID
- current stage
- risks
- next checkpoint
- rollback trigger if relevant

### 6. Handoff Notice
Include:
- artifact completed
- summary
- next owner
- expected response or action

## Enforcement rules

- Do not produce vague Slack updates.
- Do not bury blockers in long prose.
- Do not omit the owner.
- Do not mix incident handling with routine status formatting; label incident updates clearly.
- Always prefer explicit dates, IDs, and action verbs.

## Completion rule

End with one line:

`Slack message ready: YES`

Then provide the final message(s) in copy/paste-ready markdown.
