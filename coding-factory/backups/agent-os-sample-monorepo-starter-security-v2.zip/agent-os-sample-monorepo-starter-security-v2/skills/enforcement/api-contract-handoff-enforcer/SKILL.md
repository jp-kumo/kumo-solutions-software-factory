---
name: api-contract-handoff-enforcer
version: 1.0.0
description: "Force contract-first backend handoffs with schemas, errors, and compatibility rules. Use when an API or integration boundary must be specified before coding."
---

# API Contract Handoff Enforcer

Use this skill when a feature changes or introduces an API, webhook, event, background job contract, or shared client-server payload.

## Objective

Produce a contract-first handoff that removes ambiguity for backend, web, mobile, and QA agents.

## Required inputs

- Approved feature brief
- Architecture RFC
- Relevant domain model decisions
- Auth rules if applicable

## Mandatory output

Always return these sections in this order:

### 1. Contract ID
Use `CONTRACT-<feature-id>-v1`.

### 2. Scope
State which endpoints, operations, or contracts are covered.

### 3. Resource / Domain Summary
Define the business entities involved.

### 4. Endpoint or Interface Definitions
For each operation, include:
- method / operation type
- path or interface name
- purpose
- auth requirement
- request schema
- response schema
- error responses
- idempotency expectations if relevant

### 5. Validation Rules
List required fields, constraints, defaults, and disallowed states.

### 6. Error Model
Define:
- error codes
- human-readable messages
- machine-usable fields
- retryability guidance

### 7. Compatibility Rules
State:
- backward compatibility expectations
- versioning strategy
- deprecation or migration path
- client impact

### 8. Test Cases Required
List API contract test cases, validation cases, auth cases, and failure cases.

### 9. Consumer Notes
Provide explicit notes for:
- web agent
- mobile agent
- QA agent

### 10. Handoff Summary
A short implementation handoff with exact constraints.

## Enforcement rules

- Do not leave schemas informal; define fields and types clearly.
- Do not omit error behavior.
- Do not omit auth/permission notes when protected data is involved.
- If the contract breaks compatibility, say so explicitly and provide a migration path.
- Include pagination, filtering, or sorting rules when relevant.

## Completion rule

End with one line:

`Ready for implementation handoff: YES` or `Ready for implementation handoff: NO`

If `NO`, identify the exact missing contract detail.
