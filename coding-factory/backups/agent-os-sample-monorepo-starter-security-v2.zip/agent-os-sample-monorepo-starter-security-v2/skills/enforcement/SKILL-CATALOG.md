# Handoff Enforcement Skill Catalog

## Purpose

These skills are not general coding helpers. They are **workflow enforcement skills** intended to make your main agent and sub-agents produce the required handoff artifacts automatically and consistently.

## Skill-to-phase map

| Delivery phase | Skill |
|---|---|
| Intake / scoping | `feature-brief-dispatch-enforcer` |
| Architecture | `architecture-rfc-handoff-enforcer` |
| API / integration design | `api-contract-handoff-enforcer` |
| Coding kickoff | `implementation-handoff-enforcer` |
| QA planning | `qa-test-plan-handoff-enforcer` |
| Release gate | `release-readiness-gatekeeper` |
| Incident response | `bug-incident-handoff-enforcer` |
| Post-release learning | `post-release-review-enforcer` |
| Slack coordination | `slack-control-tower-coordinator` |

## Operating pattern

1. Invoke the phase skill.
2. Require the agent to return the exact sections defined by that skill.
3. Use the output as the formal artifact for the next team member.
4. Reject any handoff that does not satisfy the completion rule.

## Completion philosophy

Each skill ends with an explicit readiness line such as:
- `Ready for architecture handoff: YES/NO`
- `Ready for coding: YES/NO`
- `Release approved: YES/NO`

This is intentional. It gives your main agent a machine-friendly checkpoint to look for before advancing work.
