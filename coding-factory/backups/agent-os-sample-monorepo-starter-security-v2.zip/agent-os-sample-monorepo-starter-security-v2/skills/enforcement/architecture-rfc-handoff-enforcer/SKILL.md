---
name: architecture-rfc-handoff-enforcer
version: 1.0.0
description: "Force architecture RFCs and design handoffs before implementation. Use when a feature needs system design, data flow, boundaries, or technical tradeoff decisions."
---

# Architecture RFC Handoff Enforcer

Use this skill when a feature brief has been approved and the next step is architectural design.

## Objective

Produce a decision-oriented architecture RFC that a coding agent can implement and a QA agent can validate.

## Required inputs

- Feature brief
- Existing stack and platform constraints
- Known integration points
- Security or compliance requirements
- Performance or scale expectations if known

## Mandatory output

Always return these sections in this order:

### 1. RFC ID
Use `RFC-<feature-id>-v1`.

### 2. Summary
A concise statement of the design objective.

### 3. Context
Relevant system background, existing components, and assumptions.

### 4. Problem Statement
What technical problem must be solved?

### 5. Proposed Design
Describe:
- components involved
- responsibilities per component
- data flow
- control flow
- integration boundaries
- failure handling strategy

### 6. Data Model Impact
List schema changes, migration needs, data retention considerations, and compatibility notes.

### 7. API / Contract Impact
List any new or changed endpoints, events, jobs, permissions, or payloads.

### 8. Alternatives Considered
List at least two alternatives and why they were rejected.

### 9. Operational Considerations
Include:
- observability
- logging
- metrics
- feature flags
- rollback approach
- deployment sequencing

### 10. Security / Compliance Considerations
Include authentication, authorization, secrets handling, data sensitivity, and auditability implications.

### 11. Risks and Mitigations
List the top risks and how they will be reduced.

### 12. Implementation Sequence
Describe the recommended order of work across backend, web, mobile, QA, and release.

### 13. Architecture Handoff Summary
Write a short handoff for implementation agents:
- what to build
- what not to change
- tests that must exist
- migration precautions

## Enforcement rules

- Do not approve "just code it" designs.
- Every RFC must include at least one rejected alternative.
- Every production-impacting design must include rollback thinking.
- If there is persistence, document migration and backward-compatibility concerns.
- If auth changes, explicitly state permission boundaries.

## Completion rule

End with one line:

`Ready for API/implementation handoff: YES` or `Ready for API/implementation handoff: NO`

If `NO`, identify the unresolved design decision.
