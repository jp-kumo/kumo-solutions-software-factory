---
name: implementation-handoff-enforcer
version: 1.0.0
description: "Force implementation handoffs for web, mobile, and backend agents with file-level plans, test obligations, and definition-of-done checks."
---

# Implementation Handoff Enforcer

Use this skill when coding work is about to begin for web, mobile, backend, or multi-surface delivery.

## Objective

Turn approved requirements and contracts into a concrete implementation handoff that reduces drift and enforces test obligations.

## Required inputs

- Feature brief
- Architecture RFC
- API contract if applicable
- Existing codebase conventions or stack assumptions

## Mandatory output

Always return these sections in this order:

### 1. Workstream
State one of:
- web
- mobile
- backend
- shared
- multi-surface

### 2. Implementation Goal
One paragraph stating what this agent must deliver.

### 3. Files / Components Likely to Change
List expected files, modules, or folders to touch.

### 4. Build Plan
Provide a step-by-step plan.

### 5. Non-Negotiable Rules
Include:
- preserve backward compatibility unless explicitly approved otherwise
- avoid unrelated refactors
- do not expose secrets or sensitive data
- keep logging structured
- maintain current coding conventions

### 6. Test Obligations
List:
- unit tests required
- integration tests required
- UI/component tests required if applicable
- E2E updates required if applicable

### 7. Edge Cases
List likely failure modes, empty states, auth states, and error paths.

### 8. Evidence Required in Final Handoff
Require the implementing agent to report:
- changed files summary
- tests added or updated
- known risks
- screenshots or run output when relevant
- exact next owner

### 9. Implementation Handoff Message
Write the copy/paste handoff for the coding agent.

## Enforcement rules

- Do not allow coding to begin without a stepwise plan.
- Do not allow "done" without tests.
- Do not allow broad refactors unless the feature brief explicitly approves them.
- If database changes are involved, require migration and rollback notes.
- If UI changes are involved, require accessibility and responsive-state checks.

## Completion rule

End with one line:

`Ready for coding: YES` or `Ready for coding: NO`

If `NO`, list the blocking missing artifacts.
