---
name: qa-test-plan-handoff-enforcer
version: 1.0.0
description: "Force test plans and quality evidence before release decisions. Use when a feature is implemented or nearing implementation completion and needs formal QA coverage."
---

# QA Test Plan Handoff Enforcer

Use this skill when a feature needs a formal test plan, test evidence requirements, or release-quality validation.

## Objective

Produce a risk-based QA handoff that defines what must be tested, how it will be tested, and what evidence is required to pass.

## Required inputs

- Feature brief
- Architecture RFC
- API contract if relevant
- Implementation summary or proposed changes
- Release risk level if known

## Mandatory output

Always return these sections in this order:

### 1. Test Plan ID
Use `TEST-<feature-id>-v1`.

### 2. Feature Summary
Briefly restate what is being tested.

### 3. Risk Assessment
Classify risk as low, medium, or high and explain why.

### 4. Test Scope
List:
- in scope
- out of scope
- assumptions
- environments needed

### 5. Test Matrix
Create categories:
- unit
- integration
- API
- UI/component
- E2E
- regression
- security/access-control
- observability/monitoring verification if applicable

### 6. Critical Scenarios
List must-pass user journeys and negative-path scenarios.

### 7. Test Data / Fixtures
Define needed accounts, records, mock data, and environment setup.

### 8. Exit Criteria
State what evidence must exist before release can proceed.

### 9. Defect Reporting Format
Define the exact defect report structure:
- title
- severity
- reproduction steps
- expected result
- actual result
- evidence
- suspected owner

### 10. QA Handoff Summary
Write the handoff message to the release gatekeeper or implementing agent.

## Enforcement rules

- Every test plan must contain negative-path testing.
- Every medium/high-risk feature must include regression scope.
- If auth or roles are involved, include permission-boundary tests.
- If data persistence changes, include migration validation and rollback verification.
- Do not accept "manual testing completed" without specifying exact scenarios.

## Completion rule

End with one line:

`Ready for release gate review: YES` or `Ready for release gate review: NO`

If `NO`, state the missing evidence or missing test scope.
