---
name: bug-incident-handoff-enforcer
version: 1.0.0
description: "Force structured production bug and incident handoffs with impact, containment, reproduction, and ownership. Use for bugs, regressions, outages, and security incidents."
---

# Bug + Incident Handoff Enforcer

Use this skill for production bugs, severe regressions, live incidents, and urgent quality or security failures.

## Objective

Produce a concise but complete incident handoff that supports fast triage, clear ownership, and safe recovery.

## Required inputs

- What happened
- When it started or was detected
- Affected platform or service
- Known impact
- Current status if known

## Mandatory output

Always return these sections in this order:

### 1. Incident ID
Use `INC-YYYYMMDD-short-name`.

### 2. Summary
One paragraph on what failed.

### 3. Impact
State:
- who is affected
- what is broken
- severity
- business impact
- whether data integrity or security may be affected

### 4. Timeline
List key timestamps:
- detected
- acknowledged
- mitigated
- resolved
If unknown, state `unknown`.

### 5. Reproduction / Signals
List:
- steps to reproduce if known
- logs, traces, screenshots, or alert evidence
- suspected entry point

### 6. Containment Actions
What should be done now to reduce harm?

### 7. Suspected Root Cause
State the current best hypothesis and confidence level.

### 8. Owners
List:
- incident commander
- technical owner
- QA owner
- communications owner if relevant

### 9. Next Actions
List the immediate next 3 to 5 actions in priority order.

### 10. Slack Incident Update
Write the exact Slack update message for the incident channel.

## Enforcement rules

- Do not speculate without labeling confidence.
- If data loss or security exposure is possible, say so clearly.
- Focus on containment first, then diagnosis, then permanent fix.
- Avoid blame language.
- Always identify an owner for the next action.

## Completion rule

End with one line:

`Ready for incident execution: YES` or `Ready for incident execution: NO`

If `NO`, identify what is still unknown and how to get it quickly.
