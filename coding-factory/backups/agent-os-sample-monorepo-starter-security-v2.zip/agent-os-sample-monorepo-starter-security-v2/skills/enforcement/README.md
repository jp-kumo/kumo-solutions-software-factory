# OpenClaw Handoff Enforcement Skills

This pack contains **OpenClaw-ready skills that enforce the handoff templates automatically** by making each agent return a required structure, apply gate checks, and refuse to mark work "ready" until mandatory sections are present.

## Included skills

1. `feature-brief-dispatch-enforcer`
2. `architecture-rfc-handoff-enforcer`
3. `api-contract-handoff-enforcer`
4. `implementation-handoff-enforcer`
5. `qa-test-plan-handoff-enforcer`
6. `release-readiness-gatekeeper`
7. `bug-incident-handoff-enforcer`
8. `post-release-review-enforcer`
9. `slack-control-tower-coordinator`

## How to use these

- Invoke the skill that matches the current delivery phase.
- Require the agent to output the named sections in the skill.
- Treat the skill output as the handoff artifact for the next sub-agent.
- Do **not** allow an agent to say "done" unless the skill's completion rules are satisfied.

## Recommended invocation order

1. Feature intake arrives
2. `feature-brief-dispatch-enforcer`
3. `architecture-rfc-handoff-enforcer`
4. `api-contract-handoff-enforcer`
5. `implementation-handoff-enforcer`
6. `qa-test-plan-handoff-enforcer`
7. `release-readiness-gatekeeper`
8. `post-release-review-enforcer`

Use `bug-incident-handoff-enforcer` for production issues and `slack-control-tower-coordinator` for channel updates, escalations, and daily/weekly status management.

## Packaging notes

These skills are text-only and intentionally declare **no scripts, no external binaries, and no required environment variables**.

## Suggested install layout

Place each folder under your OpenClaw/OpenClaw-compatible skills directory so each folder contains a `SKILL.md`.
