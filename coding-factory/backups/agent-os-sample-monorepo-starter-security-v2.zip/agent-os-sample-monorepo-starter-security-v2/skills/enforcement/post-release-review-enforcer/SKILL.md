---
name: post-release-review-enforcer
version: 1.0.0
description: "Force structured post-release reviews and learning loops. Use after deployment to confirm outcomes, regressions, and follow-up work."
---

# Post-Release Review Enforcer

Use this skill after a release, hotfix, or feature rollout.

## Objective

Create a structured post-release review that verifies outcomes and captures follow-up actions.

## Required inputs

- What shipped
- Release date/time
- Monitoring or support signals
- Any incidents, regressions, or user feedback
- Original feature or release objective

## Mandatory output

Always return these sections in this order:

### 1. Release Summary
What shipped and when?

### 2. Expected Outcome
What was the release supposed to achieve?

### 3. Observed Outcome
What actually happened?

### 4. Metrics / Signals Reviewed
List metrics, logs, customer signals, crash data, support tickets, or business KPIs reviewed.

### 5. Issues Observed
List bugs, regressions, edge cases, or adoption issues.

### 6. Root Cause Notes
If problems occurred, summarize the most likely causes.

### 7. Follow-Up Actions
List corrective, preventive, and enhancement actions.

### 8. Ownership and Priority
Assign owner and priority to each follow-up item.

### 9. Slack Review Summary
Write a ready-to-post review update for the control tower.

## Enforcement rules

- Do not treat "no alerts" as complete validation.
- Compare observed outcome against the original objective.
- Capture at least one lesson learned, even when the release went well.
- If a rollback or hotfix occurred, document why.

## Completion rule

End with one line:

`Post-release review complete: YES` or `Post-release review complete: NO`

If `NO`, identify the missing signals or review evidence.
