# Subagent Skill Starter Pack

This bundle contains OpenClaw-ready starter skills for a production-quality web/mobile software-delivery team.

## Included skills
- `main-agent-orchestrator`
- `architect-agent-rfc-and-contracts`
- `web-agent-nextjs`
- `mobile-agent-expo-react-native`
- `api-data-agent-spring-kotlin-postgres`
- `qa-test-automation-agent`
- `platform-release-agent`
- `security-compliance-agent`

## How to use
1. Install or copy each folder as an individual skill.
2. Attach each skill to the corresponding sub-agent role.
3. Start with the default role charters in the markdown manual.
4. Tighten each skill after one or two pilot features:
   - add your repository paths
   - add your branch and PR policy
   - add your exact test commands
   - add your Slack channel names
   - add your release evidence requirements

## Suggested first customizations
- add product-specific naming conventions
- add ADR and handoff templates
- add your preferred API response and error format
- add CI/CD commands and environment names
- add regulated-domain controls if needed

## Notes
These are starter skills, not final skills. They are meant to give each sub-agent a clear mission, workflow, guardrails, and handoff contract with minimal ambiguity.
