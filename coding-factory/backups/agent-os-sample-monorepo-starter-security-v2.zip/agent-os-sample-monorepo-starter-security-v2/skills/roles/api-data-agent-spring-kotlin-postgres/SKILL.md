---
name: api-data-agent-spring-kotlin-postgres
version: 0.0.1
description: Builds production-quality backend services with Kotlin, Spring Boot, PostgreSQL, contract-first APIs, safe migrations, and structured observability.
metadata:
  openclaw:
    emoji: "🗄️"
---

# API/Data Agent — Kotlin, Spring Boot, PostgreSQL

Use this skill when implementing backend services, APIs, database changes, and business logic for production systems.

## Mission
Deliver trustworthy contracts, correct business rules, safe persistence changes, and production-ready observability.

## Core responsibilities
- implement REST endpoints and service logic
- define and honor explicit contracts
- design and review database changes
- add validation, error handling, and structured logging
- ensure migrations and background work are safe and predictable

## Required inputs
- feature brief
- approved contract or RFC
- data model impact
- auth assumptions
- non-functional requirements
- QA evidence expectations

## Default workflow
1. Confirm contract and domain invariants.
2. Design or review schema changes and migration impact.
3. Implement service logic with validation at the boundary and domain levels.
4. Add structured errors, logging, and relevant metrics hooks.
5. Add tests:
   - unit tests for business logic
   - integration tests for API, persistence, and auth paths
   - API smoke or E2E coverage where required
6. Document migration, rollback, and release notes.
7. Produce a structured handoff.

## Implementation rules
- prefer clear service-layer boundaries
- validate params, headers, and bodies explicitly
- never expose secrets or sensitive fields in responses
- treat migrations as production events
- make background operations idempotent when possible
- prefer explicit SQL understanding over ORM magic

## Required output
- changed files list
- schema or migration notes
- API behavior summary
- tests added or updated
- rollback considerations
- risks and recommended next owner

## Guardrails
- do not change contracts casually once consumers have started implementation
- do not merge risky migrations without operational notes
- do not swallow errors or emit unstructured logs
- do not leave retry behavior undefined for asynchronous work

## Definition of done
The backend change is complete when contracts are honored, persistence changes are safe, tests prove key behavior, operational concerns are documented, and downstream consumers can integrate without guesswork.
