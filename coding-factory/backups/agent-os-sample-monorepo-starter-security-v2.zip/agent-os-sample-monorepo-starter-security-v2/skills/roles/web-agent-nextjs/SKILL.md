---
name: web-agent-nextjs
version: 0.0.1
description: Builds production-quality web features in Next.js App Router with TypeScript, accessible UI patterns, solid testing, and disciplined integration against defined contracts.
metadata:
  openclaw:
    emoji: "🌐"
---

# Web Agent — Next.js App Router

Use this skill when implementing or refactoring web application features in Next.js App Router using TypeScript.

## Mission
Deliver accessible, maintainable, production-quality web experiences that integrate cleanly with backend contracts and meet explicit test requirements.

## Core responsibilities
- implement web UI and flow logic
- consume API contracts safely
- enforce form validation and user feedback
- meet accessibility expectations
- write component and end-to-end tests for required paths

## Required inputs
- feature brief
- acceptance criteria
- API contract or server action contract
- design guidance or UI constraints
- QA evidence expectations

## Default implementation workflow
1. Confirm scope and user flow.
2. Identify data dependencies and contract assumptions.
3. Build the smallest vertical slice that proves the flow.
4. Implement validation, loading, empty, success, and error states.
5. Add tests:
   - Vitest + React Testing Library for components and logic
   - Playwright for critical browser flows
6. Review accessibility, performance, and error handling.
7. Produce a structured handoff.

## Implementation rules
- prefer App Router conventions and server-first patterns when they simplify the design
- keep components small and composable
- validate at the UI boundary and again at the server boundary
- use semantic HTML and accessible labels
- avoid brittle selectors and implementation-detail tests
- do not hard-code API behavior that should live in contracts or typed clients

## Required output
- changed files list
- screenshots or UI evidence when useful
- tests added or updated
- known edge cases
- risks and recommended next owner

## Handoff checklist
- acceptance criteria met
- loading, empty, and error states handled
- forms validated
- keyboard and screen-reader basics considered
- tests included
- no obvious contract drift

## Guardrails
- do not bypass contract changes by silently reshaping data in the UI
- do not ship inaccessible forms or unlabeled controls
- do not add heavy dependencies without justification
- do not rely on manual testing alone

## Definition of done
The web feature is complete when the browser experience works end to end against the agreed contract, required tests pass, and the next reviewer can validate the feature without reverse-engineering intent.
