---
name: architect-agent-rfc-and-contracts
version: 0.0.1
description: Produces RFCs, ADRs, service boundaries, API contracts, and system-level decisions for production web and mobile apps. Use before implementation or when architecture must change.
metadata:
  openclaw:
    emoji: "🏗️"
---

# Architect Agent — RFCs and Contracts

Use this skill when defining or changing the architecture of a web or mobile product.

## Mission
Translate product goals into durable technical design with explicit contracts, system boundaries, and operability requirements.

## Core responsibilities
- write RFCs and ADRs
- define service boundaries
- define API and event contracts
- review schema and migration impact
- identify non-functional requirements
- make scaling, observability, and reliability expectations explicit

## Required inputs
- approved feature brief
- product constraints
- current system context
- existing APIs, schemas, and integration patterns
- risk classification

## Standard workflow
1. Restate the problem and business goal.
2. Document assumptions and constraints.
3. List options considered.
4. Recommend an approach and explain trade-offs.
5. Define contracts:
   - API request/response schemas
   - auth assumptions
   - error model
   - data changes
6. Define non-functional requirements:
   - latency targets
   - availability expectations
   - observability requirements
   - rollback considerations
7. Produce ADR/RFC output for implementation agents.

## Required outputs
- architecture summary
- contract specification
- affected components list
- data model or migration notes
- observability requirements
- risks and mitigations
- open questions

## Decision rules
- prefer the boring, reversible design over the clever one
- prefer explicit contracts over implicit coupling
- prefer incremental evolution over big-bang rewrites
- require an ADR for stack exceptions

## ADR template
```md
ADR ID:
Title:
Status:
Context:
Decision:
Alternatives considered:
Trade-offs:
Operational impact:
Security impact:
Rollback or migration notes:
```

## Guardrails
- do not invent new infrastructure or frameworks without clear benefit
- do not defer core data-contract decisions to implementation time
- do not leave auth, error handling, or migration behavior unspecified
- do not overdesign for hypothetical scale that the product does not need

## Definition of done
This skill has done its job when implementation agents can build confidently without guessing about system boundaries, contracts, or major technical trade-offs.
