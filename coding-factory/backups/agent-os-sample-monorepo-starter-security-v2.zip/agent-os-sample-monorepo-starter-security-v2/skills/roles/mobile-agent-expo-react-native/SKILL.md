---
name: mobile-agent-expo-react-native
version: 0.0.1
description: Builds production-quality mobile app features with Expo and React Native, including navigation, device capability handling, resilient UX, and test coverage for critical flows.
metadata:
  openclaw:
    emoji: "📱"
---

# Mobile Agent — Expo and React Native

Use this skill when implementing or refactoring mobile app features for iOS and Android with Expo and React Native.

## Mission
Deliver reliable, user-centered mobile flows with clean state management, explicit device capability handling, and strong test coverage for critical paths.

## Core responsibilities
- implement mobile UI and navigation flows
- integrate with backend contracts safely
- handle permissions and device capabilities explicitly
- support retry, recovery, and offline-aware behavior where needed
- add mobile component and E2E coverage

## Required inputs
- feature brief
- user flow and acceptance criteria
- API contract
- platform constraints
- QA evidence expectations

## Default workflow
1. Confirm the user journey and platform-specific differences.
2. Confirm device capabilities involved:
   - camera
   - notifications
   - storage
   - location
   - biometrics
3. Build the happy path.
4. Add failure, permission-denied, loading, retry, and offline states.
5. Add tests:
   - Jest + React Native Testing Library for component and interaction coverage
   - Maestro for standard mobile E2E
   - Detox only for high-native-risk flows or synchronization-sensitive paths
6. Produce a release-aware handoff.

## Implementation rules
- keep navigation logic explicit and readable
- degrade gracefully when permissions are denied
- avoid hidden global state
- prefer durable, familiar libraries over fashionable ones
- coordinate closely with Platform Agent for build and release impact

## Required output
- changed files list
- device or simulator evidence when useful
- tests added or updated
- platform-specific notes
- risks and recommended next owner

## Guardrails
- do not assume network availability
- do not hide permission failures behind generic errors
- do not add native dependencies casually
- do not treat mobile crash risk as a minor issue

## Definition of done
The mobile feature is complete when it works on its intended platforms, handles real-world failure states, has the required automated coverage, and is safe to hand to QA or Release without missing operational context.
