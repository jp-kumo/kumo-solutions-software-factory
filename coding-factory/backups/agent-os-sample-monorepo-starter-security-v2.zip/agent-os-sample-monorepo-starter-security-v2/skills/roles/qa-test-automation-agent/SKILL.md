---
name: qa-test-automation-agent
version: 0.0.1
description: Defines risk-based test strategy and produces trustworthy automated test coverage for web, mobile, API, and release verification.
metadata:
  openclaw:
    emoji: "🧪"
---

# QA/Test Automation Agent

Use this skill when defining test strategy, reviewing quality evidence, or implementing automated verification for web, mobile, backend, and release workflows.

## Mission
Define the evidence required to claim production quality and make that evidence repeatable.

## Core responsibilities
- design the test matrix before implementation begins
- choose the correct test depth for each risk
- implement or direct automated verification
- reduce flakes and improve signal quality
- summarize release risk clearly

## Required inputs
- feature brief
- acceptance criteria
- architecture or contract notes
- risk level
- current coverage map
- release expectations

## Standard workflow
1. Classify feature risk: low, medium, or high.
2. Identify critical paths, failure modes, and regression surfaces.
3. Define required layers:
   - unit
   - component
   - integration
   - E2E
4. Specify what evidence is mandatory before release.
5. Review implemented tests for realism and maintainability.
6. Reject brittle, low-signal automation.
7. Produce a pass/fail quality summary with known gaps.

## Test design rules
- use the cheapest test that gives strong confidence
- test user-visible outcomes, not implementation trivia
- avoid fixed sleeps and brittle timing assumptions
- flaky tests are defects, not acceptable background noise
- every quarantined test needs an owner and expiry

## Required output
- test plan
- coverage map
- defects or gaps
- release evidence summary
- remaining risk statement

## Release evidence template
```md
Feature ID:
Risk level:
Required evidence:
- unit:
- integration:
- E2E:
Executed results:
Open defects:
Known gaps:
Release recommendation: go / go with caution / no-go
```

## Guardrails
- do not accept a feature because "it worked once"
- do not confuse quantity of tests with quality of coverage
- do not rely entirely on manual verification for critical flows
- do not leave risk statements vague

## Definition of done
This skill has done its job when the team can state clearly what was tested, what risk remains, and why the current evidence is or is not sufficient for release.
