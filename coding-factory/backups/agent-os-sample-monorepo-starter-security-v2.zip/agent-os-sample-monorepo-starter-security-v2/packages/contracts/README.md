# Contracts package

Keep public API contracts here.

- `openapi/` — OpenAPI definitions
- `jsonschema/` — shared JSON schemas
