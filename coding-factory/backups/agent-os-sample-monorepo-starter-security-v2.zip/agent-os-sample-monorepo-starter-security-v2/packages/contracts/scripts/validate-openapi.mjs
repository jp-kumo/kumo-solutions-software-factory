import fs from "node:fs";
import path from "node:path";

const filePath = path.resolve("openapi/app-api.yaml");

if (!fs.existsSync(filePath)) {
  console.error("Missing OpenAPI file:", filePath);
  process.exit(1);
}

const text = fs.readFileSync(filePath, "utf8");
const requiredTokens = ["openapi:", "info:", "paths:"];
const missing = requiredTokens.filter((token) => !text.includes(token));

if (missing.length) {
  console.error("OpenAPI file is missing required sections:", missing.join(", "));
  process.exit(1);
}

console.log("Basic OpenAPI presence checks passed.");
