# Terraform environment placeholder

Add your cloud provider configuration, remote state, network, database, secrets, and compute here.

Suggested pattern:
- `providers.tf`
- `versions.tf`
- `main.tf`
- `variables.tf`
- `outputs.tf`
- `terraform.tfvars.example`
