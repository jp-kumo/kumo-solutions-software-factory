# List Template: Incident Tracking

## Purpose
Track active and resolved incidents, owners, severities, and corrective actions.

## Recommended list name
`<project-name> incident tracking`

## Suggested columns
- Incident ID
- Severity
- Summary
- Status (`declared`, `investigating`, `mitigating`, `monitoring`, `resolved`, `postmortem`) 
- Incident commander
- Start time
- Resolved time
- Customer impact
- Root cause summary
- Corrective action owner
- Slack thread link
- Postmortem link

## Suggested views
- active incidents
- by severity
- needs postmortem
- open corrective actions

## Operating rule
Every declared incident gets a list row immediately.

