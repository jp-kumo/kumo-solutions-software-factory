# List Template: Backlog and Delivery

## Purpose
Track requests from intake through dispatch, implementation, review, release readiness, and shipment.

## Recommended list name
`<project-name> backlog and delivery`

## Suggested columns
- Item ID
- Title
- Type (`feature`, `bug`, `incident follow-up`, `ops`, `tech debt`)
- Priority (`P0`, `P1`, `P2`, `P3`)
- Status (`new`, `triage`, `ready`, `in progress`, `blocked`, `review`, `release-ready`, `done`)
- Owner agent
- Human owner (optional)
- Sprint / window
- Due date
- Risk level
- Link to Slack thread
- Link to PR / ticket / doc

## Suggested views
- by status
- by priority
- by owner agent
- blocked items
- release-ready items

## Operating rule
Every intake workflow submission should create or update a row in this list.

