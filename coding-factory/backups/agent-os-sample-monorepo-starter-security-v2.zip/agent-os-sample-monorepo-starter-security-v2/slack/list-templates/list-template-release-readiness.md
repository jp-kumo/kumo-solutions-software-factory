# List Template: Release Readiness

## Purpose
Track release candidates and evidence required for go/no-go decisions.

## Recommended list name
`<project-name> release readiness`

## Suggested columns
- Release ID
- Version/build
- Environment
- Scope summary
- QA status
- Migration status
- Rollback ready (`yes/no`)
- Monitoring ready (`yes/no`)
- Main agent approval
- Human approval
- Planned date
- Slack thread link
- Release notes link

## Suggested views
- upcoming releases
- missing approvals
- blocked releases
- completed releases

## Operating rule
Every production or staging candidate should have a list row before deployment starts.

