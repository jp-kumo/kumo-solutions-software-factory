# Delivery Lane Canvas

## Purpose
Use this canvas in the web, mobile, API, or QA channel to keep lane-specific standards, priorities, and handoff expectations visible.

## Lane
- Name: <web|mobile|api|qa>
- Owner agent:
- Backup reviewer:

## This sprint / current window
| Task ID | Description | Status | Owner | Target gate |
|---|---|---|---|---|
| <id> | <task> | <status> | <owner> | <gate> |

## Lane standards
### Required for every task
- clear task ID
- implementation plan in thread
- tests added or updated
- evidence attached before handoff
- risks called out explicitly

### Required handoff fields
- objective completed
- inputs used
- artifacts created
- tests added or updated
- known risks
- open questions
- ready for next stage

## Lane-specific checklist
### Web
- accessibility checked
- loading/error/empty states present
- route-level performance considered
- browser E2E smoke added when needed

### Mobile
- device permissions reviewed
- navigation and error states tested
- offline/resume behavior considered
- mobile E2E flow covered

### API
- request/response contracts updated
- validation and error handling present
- migrations reviewed
- logging and metrics present

### QA
- risk-based test plan created
- test coverage mapped to acceptance criteria
- flake risk evaluated
- release confidence summary prepared

## Ready-for-review template
```text
[READY FOR REVIEW] <TASK-ID>
Lane:
Work completed:
Tests:
Evidence:
Known risks:
Needs from next owner:
```

## Important links
- repo:
- CI:
- standards:
- dashboards:

