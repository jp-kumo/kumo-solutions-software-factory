# Release Canvas

## Purpose
Keep release readiness visible and make go/no-go decisions disciplined and repeatable.

## Release calendar
| Release ID | Environment | Planned date | Owner | Status |
|---|---|---|---|---|
| <id> | <env> | <date> | <owner> | <status> |

## Release checklist
- scope finalized
- all PRs linked
- CI passing
- migrations validated
- smoke tests passing
- rollback plan documented
- monitoring prepared
- approvers identified

## Current candidate
- Release ID:
- Version:
- Environment:
- Scope summary:
- Known risks:
- Rollback owner:

## Approval matrix
| Role | Name/Agent | Status | Notes |
|---|---|---|---|
| Main agent | <name> | <status> | <notes> |
| QA agent | <name> | <status> | <notes> |
| Platform agent | <name> | <status> | <notes> |
| Human principal | <name> | <status> | <notes> |

## Post-release validation
- deployment completed
- smoke checks passed
- logs normal
- alerts normal
- critical flows verified
- user-facing issues monitored

## Release review template
```text
[RELEASE REVIEW] <RELEASE-ID>
Version:
Scope:
Risks:
Quality status:
Migration status:
Rollback plan:
Recommendation:
Approvals needed:
Links:
- 
```

