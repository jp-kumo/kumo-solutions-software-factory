# Intake Canvas

## Purpose
Central place for request intake policy, prioritization rules, and triage outcomes for this project.

## Intake policy
All new work should arrive through a structured form when possible.

Accepted work types:
- feature request
- bug report
- release request
- incident report
- platform or process improvement

## Prioritization rubric
### P0
- active customer outage
- severe security issue
- data loss or corruption risk

### P1
- high customer impact without full outage
- release-blocking defect
- critical compliance issue

### P2
- standard feature work
- non-blocking defect with material user friction

### P3
- nice-to-have improvements
- backlog grooming candidates

## Definition of ready
A request is ready for dispatch when it has:
- clear problem statement
- owner identified
- acceptance criteria
- dependencies called out
- links to supporting artifacts

## Triage board snapshot
| Request ID | Type | Priority | Status | Owner | Next step |
|---|---|---|---|---|---|
| <id> | <type> | <priority> | <status> | <owner> | <next step> |

## Standard dispositions
- accepted
- needs more info
- duplicate
- parked
- rejected
- escalated to incident

## Triage summary template
```text
[TRIAGE] <REQUEST-ID>
Type:
Priority:
Disposition:
Owner:
Next step:
Links:
- 
```

## Supporting links
- roadmap:
- bug severity rubric:
- project brief:
- customer escalation path:

