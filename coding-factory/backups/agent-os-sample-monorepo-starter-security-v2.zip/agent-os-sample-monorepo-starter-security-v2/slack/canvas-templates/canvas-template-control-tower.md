# Control Tower Canvas

## Mission
Run a predictable software delivery system where the main agent owns prioritization, dispatch, cross-agent coordination, and release authority.

## Team roles
- Main agent — orchestrator and release authority
- Architect agent — design decisions and ADRs
- Web agent — web product delivery
- Mobile agent — mobile product delivery
- API/data agent — backend contracts, services, persistence
- QA/test agent — verification and quality gates
- Platform/release agent — CI/CD, environments, releases
- Security/compliance agent — optional risk and control review

## Active priorities
1. <priority 1>
2. <priority 2>
3. <priority 3>

## Current release window
- Next target release:
- Freeze starts:
- Go/no-go review:
- Rollback owner:

## Decision log
| Date | Decision | Owner | Link |
|---|---|---|---|
| <date> | <decision> | <owner> | <link> |

## Risk register
| Risk | Severity | Owner | Mitigation | Status |
|---|---|---|---|---|
| <risk> | <level> | <owner> | <plan> | <status> |

## Current blockers
| Task ID | Blocker | Owner | Since | Escalation path |
|---|---|---|---|---|
| <id> | <blocker> | <owner> | <date> | <path> |

## Channel operating rules
- The main agent posts daily summary at the same time every workday.
- All dispatches must include task ID, owner, acceptance criteria, and next gate.
- All detailed execution discussion belongs in threads.
- No task is marked complete without links to artifacts and test evidence.

## Daily summary template
```text
[DAILY SUMMARY] <date>
Shipped yesterday:
- 
In progress today:
- 
Blocked:
- 
Risks:
- 
Decisions needed:
- 
Release status:
- 
```

## Quick links
- backlog:
- release board:
- incident board:
- architecture repo:
- monitoring:
- CI/CD:

