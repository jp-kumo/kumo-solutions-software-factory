# Architecture Canvas

## Purpose
Track architecture decisions, technical standards, and implementation boundaries for this project.

## System summary
- Product:
- Problem domain:
- Primary users:
- Core services:
- Data stores:
- Integrations:

## Architecture principles
1. Prefer boring, durable technology.
2. Design contracts before implementation.
3. Keep boundaries explicit between web, mobile, API, data, and platform concerns.
4. Optimize for observability and rollback, not just feature velocity.
5. Make migrations reversible whenever practical.

## Current target stack
- Web: Next.js + TypeScript
- Mobile: Expo/React Native + TypeScript
- Backend: Kotlin + Spring Boot
- Database: PostgreSQL
- Web test stack: Vitest, React Testing Library, Playwright
- Mobile test stack: Jest, React Native Testing Library, Maestro

## ADR index
| ADR ID | Title | Status | Owner | Link |
|---|---|---|---|---|
| <id> | <title> | <status> | <owner> | <link> |

## Open decisions
| Decision | Why needed | Options | Decision owner | Due |
|---|---|---|---|---|
| <decision> | <reason> | <options> | <owner> | <date> |

## Data and contract changes
| Change ID | Type | Risk | Rollback note | Owner |
|---|---|---|---|---|
| <id> | <api/db/auth> | <risk> | <rollback> | <owner> |

## Review checklist
- problem and scope defined
- alternatives considered
- data impact reviewed
- auth/security impact reviewed
- observability and alerts updated
- rollback path identified

## Decision summary template
```text
[ARCH DECISION] <ADR-ID>
Status:
Summary:
Rationale:
Impacted systems:
Required follow-up:
Links:
- 
```

