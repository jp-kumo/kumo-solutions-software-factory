# Incident Canvas

## Purpose
Coordinate fast, structured response to active production incidents.

## Severity definitions
### SEV1
Major outage, critical customer impact, or severe security/data integrity issue.

### SEV2
Major degradation, limited outage, or serious release issue with high user impact.

### SEV3
Contained issue with moderate impact or workaround available.

## Active incidents
| Incident ID | Severity | Summary | Owner | Start time | Status |
|---|---|---|---|---|---|
| <id> | <sev> | <summary> | <owner> | <time> | <status> |

## Response rules
- one incident thread per incident
- update at the severity cadence
- capture timeline as you go
- separate facts from hypotheses
- declare mitigation and rollback decisions explicitly

## Incident timeline
| Time | Event | Owner |
|---|---|---|
| <time> | <event> | <owner> |

## Stakeholder comms
- status page:
- customer support:
- internal leadership:
- engineering:

## Post-incident follow-up
- root cause documented
- contributing factors documented
- corrective actions assigned
- monitoring or alerting improvements logged
- postmortem scheduled

## Incident declaration template
```text
[INCIDENT] <INC-ID> | Severity <SEV>
Summary:
Customer impact:
Start time:
Current owner:
Current hypothesis:
Immediate mitigation:
Next update by:
Links:
- 
```

