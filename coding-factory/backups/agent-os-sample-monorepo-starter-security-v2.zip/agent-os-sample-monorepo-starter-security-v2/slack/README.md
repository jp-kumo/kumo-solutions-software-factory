# Slack Channel, Canvas, and Workflow Template Pack

This pack gives you a repeatable Slack operating system for a main-agent-led software delivery team. It is designed to support the operating manual and assumes the following pattern:

- one **main agent** acts as product manager, engineering manager, and release authority
- specialist sub-agents work in dedicated delivery channels
- Slack is the **control plane** for intake, dispatch, decisions, handoffs, blockers, and release coordination
- Git, CI/CD, and your issue tracker remain the sources of truth for code, build status, and deployment history

## What is in this pack

### 1. Channel templates
Located in `channel-templates/`

Use these files to create or standardize Slack channels:
- `channel-template-agent-control-tower.md`
- `channel-template-project-intake.md`
- `channel-template-architecture.md`
- `channel-template-delivery-lane.md`
- `channel-template-release.md`
- `channel-template-incidents.md`

### 2. Canvas templates
Located in `canvas-templates/`

Use these as copy/paste starting points for channel canvases:
- `canvas-template-control-tower.md`
- `canvas-template-intake.md`
- `canvas-template-architecture.md`
- `canvas-template-delivery-lane.md`
- `canvas-template-release.md`
- `canvas-template-incidents.md`

### 3. Workflow templates
Located in `workflow-templates/`

Use these to build Slack Workflow Builder forms and automations:
- `workflow-template-feature-request-form.md`
- `workflow-template-bug-report-form.md`
- `workflow-template-release-request-form.md`
- `workflow-template-incident-report-form.md`
- `workflow-template-daily-status-collection.md`

### 4. List templates
Located in `list-templates/`

Use these for Slack lists that track delivery status:
- `list-template-backlog-and-delivery.md`
- `list-template-release-readiness.md`
- `list-template-incident-tracking.md`

## Recommended channel layout

Create these channels for each product or major initiative:

- `#agent-control-tower`
- `#proj-<name>-intake`
- `#proj-<name>-arch`
- `#proj-<name>-web`
- `#proj-<name>-mobile`
- `#proj-<name>-api`
- `#proj-<name>-qa`
- `#proj-<name>-release`
- `#proj-<name>-incidents`

## Recommended operating rules

1. The **main agent** owns top-level dispatch, prioritization, cross-agent coordination, and release decisions.
2. Each feature or issue gets **one top-level dispatch message** and all execution happens in that message thread.
3. Every project channel has:
   - a channel canvas
   - a channel list or linked project list
   - a small set of bookmarked workflows
4. Channel messages are for:
   - dispatch
   - escalations
   - decisions
   - handoffs
   - release approvals
5. Threads are for:
   - implementation details
   - QA findings
   - design discussion
   - unblockers
6. Slack is not the source of truth for code or deployment logs. Always link out to:
   - Git repo
   - PR
   - CI run
   - test evidence
   - release artifact
   - monitoring dashboard

## Suggested rollout order

1. Create `#agent-control-tower`
2. Create one pilot project channel set
3. Add canvases to each channel
4. Add lists for backlog, release, and incidents
5. Create the intake, bug, release, and incident workflows
6. Train the main agent to enforce thread discipline and handoff format
7. Run a two-week pilot before rolling this out to all projects

## Main agent message contract

Every dispatch message from the main agent should include:

- Task ID
- Priority
- Goal
- Acceptance criteria
- Assigned agent
- Dependencies
- Target gate or due date
- Links to source artifacts
- Required outputs
- Next review checkpoint

## Copy/paste starter dispatch template

```text
[DISPATCH] <TASK-ID> | <priority> | <owner-agent>
Goal: <what outcome is required>
Why it matters: <business or product reason>
Acceptance criteria:
- <criterion 1>
- <criterion 2>
- <criterion 3>
Dependencies:
- <dependency 1>
- <dependency 2>
Artifacts:
- PRD: <link>
- ADR/RFC: <link>
- API contract: <link>
- Design/prototype: <link>
Required outputs:
- <artifact 1>
- <artifact 2>
Risk notes:
- <risk 1>
Next checkpoint: <date/time or event>
```

## Handoff contract

Every agent handoff should include:

```text
[HANDOFF] <TASK-ID> | from <agent> to <agent>
Objective completed:
Inputs used:
Artifacts created:
Tests added or updated:
Known risks:
Open questions:
Ready for next stage: yes/no
Links:
- <link 1>
- <link 2>
```

## How to use this pack

- Start with the channel template that matches the channel you are creating.
- Paste the matching canvas template into the channel canvas.
- Build the matching workflow forms in Workflow Builder.
- Attach the recommended list template to the channel or to a shared project operations channel.
- Bookmarked workflows should be visible in the channel header or pinned resources area.

