# Workflow Template: Daily Status Collection

## Goal
Collect consistent daily updates from agents and publish a compact operating summary into `#agent-control-tower`.

## Recommended workflow name
`Daily status collection`

## Recommended destination
`#agent-control-tower`

## Trigger
Scheduled workflow every workday at a fixed time.

## Form fields
1. Agent name — dropdown — required
2. Shipped yesterday — long text — optional
3. In progress today — long text — required
4. Current blockers — long text — optional
5. Risks or concerns — long text — optional
6. Decision needed from main agent or principal — long text — optional
7. Confidence (`green`, `yellow`, `red`) — dropdown — required

## Workflow steps
1. Scheduled trigger prompts each agent or responsible user
2. Responses are collected
3. Workflow posts a summary message in control tower
4. Main agent follows up where confidence is yellow or red

## Summary message template
```text
[DAILY STATUS COLLECTION] <date>
<agent 1> — Confidence: <green/yellow/red>
Shipped yesterday: <text>
In progress today: <text>
Blockers: <text>
Risks: <text>
Decision needed: <text>

<agent 2> — Confidence: <green/yellow/red>
...
```

## Follow-up rule
Any red status triggers a same-day thread review by the main agent.

