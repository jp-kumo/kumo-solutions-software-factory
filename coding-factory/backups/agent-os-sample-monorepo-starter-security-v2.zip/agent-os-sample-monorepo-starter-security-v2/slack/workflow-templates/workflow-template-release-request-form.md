# Workflow Template: Release Request Form

## Goal
Standardize release candidate submission so go/no-go review is based on consistent evidence.

## Recommended workflow name
`Submit release request`

## Recommended destination
`#proj-<name>-release`

## Form fields
1. Release ID — short text — required
2. Version/build number — short text — required
3. Environment — dropdown (`staging`, `production`, `other`) — required
4. Scope summary — long text — required
5. Linked PRs or change sets — long text — required
6. Test evidence links — long text — required
7. Migration required? — yes/no — required
8. Migration plan / notes — long text — conditional
9. Rollback plan — long text — required
10. Risks and known issues — long text — required
11. Requested release window — date/time — required
12. Requestor — short text — required

## Workflow steps
1. Release owner submits form
2. Workflow posts a release candidate message in release channel
3. Workflow adds row to release readiness list
4. Workflow tags main agent, QA agent, and platform/release agent
5. Workflow creates a thread for approvals and validation updates

## Posted message template
```text
[RELEASE REQUEST] <release id>
Version/build: <version>
Environment: <environment>
Requested window: <window>
Scope:
<scope>
Linked PRs/changes:
<changes>
Test evidence:
<evidence>
Migration required: <yes/no>
Migration notes:
<migration notes>
Rollback plan:
<rollback>
Known risks:
<risks>
Requested by: <requestor>
```

## Approval rule
No production deployment begins until required approvers reply in thread or the release canvas reflects explicit approval state.

