# Channel Template: `#proj-<name>-release`

## Purpose
This channel controls release preparation, go/no-go decisions, rollback readiness, and production deployment coordination.

## Owners
- Platform/release agent: primary owner
- Main agent: release authority
- QA agent: quality sign-off owner

## Recommended privacy
Private by default.

## Channel description
`Release planning, readiness, approvals, deployment coordination, and rollback management for <project-name>.`

## Posting rules
Allowed top-level posts:
- release candidate announcement
- release checklist status
- go/no-go review
- deploy start/end notice
- rollback announcement
- hotfix release notice
- post-release validation summary

## Thread rules
One thread per release candidate. All deployment notes, approvals, and validation outcomes live in that thread.

## Required bookmarks / pinned resources
- release calendar
- rollback playbook
- release checklist
- environment status dashboard
- monitoring dashboard
- incident escalation contacts

## Suggested workflows
- release request form
- go/no-go checklist acknowledgement
- hotfix request form

## Required pre-release evidence
- PRs merged and linked
- CI passing
- migration plan validated
- smoke tests passing
- rollback plan documented
- monitoring checks ready

## Go/no-go template
```text
[RELEASE REVIEW] <RELEASE-ID>
Version:
Scope:
Risks:
Quality status:
Migration status:
Rollback plan:
Recommendation: go | no-go
Approvers needed:
Links:
- <release notes>
- <CI run>
- <dashboard>
```

