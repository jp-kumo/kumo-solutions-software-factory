# Channel Template: `#proj-<name>-arch`

## Purpose
This channel is the design and decision lane for architecture, data model changes, API contracts, integration patterns, and major technical tradeoffs.

## Owners
- Architect agent: primary owner
- API/data agent: secondary owner
- Main agent: approval and sequencing owner

## Recommended privacy
Private by default.

## Channel description
`Architecture, ADRs, contracts, and system design decisions for <project-name>. Keep implementation chatter out.`

## Posting rules
Allowed top-level posts:
- RFC submission
- ADR proposal
- API contract review
- database migration review
- dependency or platform decision
- approved decision summary

Not allowed as top-level posts:
- small implementation details better handled in delivery channels
- generic brainstorming without a decision target

## Thread rules
All review discussion happens in the proposal thread. When a decision is final, the thread ends with one decision post containing:
- decision
- rationale
- impacted systems
- rollout implications
- owner for implementation

## Required bookmarks / pinned resources
- ADR index
- system diagram
- data model diagram
- API standards
- security standards
- performance budgets

## Suggested workflows
- RFC submission workflow
- migration review workflow
- architecture exception request workflow

## Review checklist
Every proposal should answer:
- what problem are we solving?
- what alternatives were considered?
- what changes in data, contracts, auth, observability, and release?
- what are the rollback implications?
- what is the blast radius?

## Approval template
```text
[ARCH DECISION] <ADR-ID>
Status: approved | approved with conditions | rejected
Summary:
Rationale:
Impacted areas:
- <area>
Required follow-up:
- <item>
Implementation owner:
Links:
- <ADR>
- <diagram>
```

