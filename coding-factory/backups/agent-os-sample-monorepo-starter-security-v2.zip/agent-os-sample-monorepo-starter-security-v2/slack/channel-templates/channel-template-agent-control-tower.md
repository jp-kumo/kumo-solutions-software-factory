# Channel Template: `#agent-control-tower`

## Purpose
This is the command channel for the entire sub-agent team. It is used by the main agent to:
- publish daily status
- dispatch major work
- assign ownership
- escalate blockers
- request decisions from the human principal
- announce release approvals and incident severity changes

## Owners
- Main agent: primary owner
- Human principal: executive reviewer and final escalation point
- Platform/release agent: secondary owner for release broadcasts

## Recommended privacy
Private by default if product and customer details are sensitive.

## Channel description
`Main control channel for software delivery dispatch, cross-agent coordination, escalation, and release authority.`

## Posting rules
Allowed top-level posts:
- daily summary from main agent
- new dispatch for major feature or incident
- decision request requiring human input
- release approval or rollback decision
- postmortem summary link

Not allowed as top-level posts:
- routine implementation chatter
- code review back-and-forth
- detailed debugging notes
- repeated status pings from sub-agents

## Thread rules
Each dispatch post gets one thread. All execution updates for that dispatch live in that thread.

## Required bookmarks / pinned resources
- team operating manual
- delivery dashboard or backlog link
- release calendar
- incident severity policy
- engineering standards
- architecture repository or ADR folder

## Suggested workflow buttons
- Submit feature request
- Submit bug report
- Submit release request
- Submit incident report
- Daily status collection

## Suggested list connections
- backlog and delivery list
- release readiness list
- incident tracking list

## Top-level post templates

### Daily summary
```text
[DAILY SUMMARY] <date>
Shipped yesterday:
- <item>
In progress today:
- <item>
Blocked:
- <item>
Risks:
- <item>
Needs decision:
- <item>
Release status:
- <item>
```

### Dispatch
```text
[DISPATCH] <TASK-ID> | <priority> | owner: <agent>
Goal: <outcome>
Acceptance criteria:
- <criterion>
Dependencies:
- <dependency>
Required outputs:
- <artifact>
Review gate: <gate>
```

### Decision request
```text
[DECISION NEEDED] <TASK-ID>
Decision owner: <human principal>
Question:
Options:
1. <option 1>
2. <option 2>
Recommendation:
Impact if delayed:
Decision deadline:
```

## Service-level expectations
- New high-priority dispatch acknowledged within 15 minutes by owner agent.
- Blockers escalated within 30 minutes once identified.
- Release go/no-go summary posted before every production deploy.

