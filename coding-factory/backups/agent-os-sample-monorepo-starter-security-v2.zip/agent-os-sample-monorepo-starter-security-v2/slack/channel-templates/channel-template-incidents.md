# Channel Template: `#proj-<name>-incidents`

## Purpose
This channel is for active production issues, triage, containment, mitigation, communication, and post-incident follow-up.

## Owners
- Main agent: incident commander by default
- Platform/release agent: operations lead
- QA agent: verification lead
- Architect agent: technical advisory lead as needed

## Recommended privacy
Private.

## Channel description
`Incident response and post-incident coordination for <project-name>.`

## Posting rules
Allowed top-level posts:
- incident declaration
- severity change
- mitigation update
- rollback/update deployment notice
- stakeholder communication summary
- incident resolved note
- postmortem link

## Thread rules
Each incident gets one top-level declaration post. All response activity stays in that thread.

## Required bookmarks / pinned resources
- severity matrix
- escalation policy
- rollback playbook
- status page links
- monitoring dashboards
- incident report form

## Suggested workflows
- incident report form
- incident status update form
- postmortem follow-up form

## Incident declaration template
```text
[INCIDENT] <INC-ID> | Severity <SEV>
Summary:
Customer impact:
Start time:
Current owner:
Current hypothesis:
Immediate mitigation:
Next update by:
Links:
- <dashboard>
- <status page>
```

## Minimum operating cadence
- SEV1: update at least every 15 minutes
- SEV2: update at least every 30 minutes
- SEV3: update at least every 60 minutes

