# Channel Template: `#proj-<name>-<lane>`

Use this template for these channels:
- `#proj-<name>-web`
- `#proj-<name>-mobile`
- `#proj-<name>-api`
- `#proj-<name>-qa`

Replace `<lane>` with the correct delivery lane.

## Purpose
This channel is for execution work owned by a specialist sub-agent. Each lane channel turns approved work into implementation artifacts, tests, and handoffs.

## Owners by lane
- web: web agent
- mobile: mobile agent
- api: API/data agent
- qa: QA/test automation agent

## Channel description
`Execution channel for <project-name> <lane> delivery. Use thread-based work tracking tied to approved dispatches.`

## Posting rules
Allowed top-level posts:
- work dispatch from main agent
- lane-specific implementation plan
- handoff received
- blocker escalation
- ready-for-review summary
- failed gate summary

Not allowed as top-level posts:
- unrelated feature brainstorming
- duplicate status updates already posted in control tower
- side conversations not tied to a task ID

## Thread rules
Each approved dispatch gets one thread. Every thread should include:
- implementation plan
- progress updates at meaningful milestones
- test evidence
- blocker notes
- handoff or completion summary

## Required bookmarks / pinned resources
- coding standards
- testing standards
- definition of done
- deployment environment links
- repo and CI links
- lane-specific runbooks

## Suggested workflows
- blocker escalation form
- review-ready handoff form
- flaky test report form

## Required message tags
Use these prefixes consistently:
- `[PLAN]`
- `[UPDATE]`
- `[BLOCKER]`
- `[READY FOR REVIEW]`
- `[HANDOFF]`
- `[FAILED GATE]`

## Ready-for-review template
```text
[READY FOR REVIEW] <TASK-ID>
Lane: <lane>
Work completed:
Tests added/updated:
Evidence:
- <PR link>
- <CI link>
- <screenshots>
Known risks:
Needs from next owner:
```

## Lane-specific guidance

### Web channel
Focus on:
- Next.js implementation
- accessibility
- performance budgets
- browser test coverage

### Mobile channel
Focus on:
- Expo/React Native implementation
- device compatibility
- offline/resume behavior
- mobile E2E coverage

### API channel
Focus on:
- contracts
- service logic
- persistence
- migrations
- auth and error handling

### QA channel
Focus on:
- test strategy
- risk-based coverage
- cross-lane validation
- flaky test triage
- release confidence

