# Channel Template: `#proj-<name>-intake`

## Purpose
This channel receives incoming work for a specific product or initiative:
- feature requests
- enhancement ideas
- bugs
- customer-reported issues
- support escalations
- internal process improvements

## Owners
- Main agent: triage authority
- Product or principal reviewer: optional approver
- QA agent: secondary owner for bug triage

## Recommended privacy
Private if customer details or unreleased roadmap information may be discussed.

## Channel description
`Intake and triage channel for new work on <project-name>. Use forms and threads; avoid ad hoc requests.`

## Posting rules
Preferred entry path:
- feature request workflow form
- bug report workflow form
- release request workflow form
- incident report workflow form

Allowed top-level posts:
- workflow submissions
- triage summaries
- accepted/rejected/parked decisions
- backlog grooming summaries

## Thread rules
Each request gets exactly one thread for triage. Final triage disposition should be posted in the thread using one of these labels:
- accepted
- needs more info
- duplicate
- parked
- rejected
- escalated to incident

## Required bookmarks / pinned resources
- intake policy
- prioritization rubric
- definition of ready
- project roadmap
- bug severity rubric

## Suggested workflows
- feature request form
- bug report form
- incident report form

## Suggested list connections
- backlog and delivery list

## Triage summary template
```text
[TRIAGE] <REQUEST-ID>
Type: <feature|bug|incident|ops>
Priority: <P0-P3>
Disposition: <accepted|needs more info|duplicate|parked|rejected>
Owner: <agent or human>
Next step:
Links:
- <artifact>
```

## Intake standards
- No request is considered valid without a clear problem statement.
- Bugs must include expected behavior, actual behavior, and environment.
- Features must include user impact and acceptance criteria.
- Incidents must include current severity and observed impact.

