package com.example.api

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@SpringBootApplication
class Application

fun main(args: Array<String>) {
    runApplication<Application>(*args)
}

data class HealthResponse(
    val success: Boolean,
    val service: String,
    val status: String,
)

@RestController
@RequestMapping("/api")
class HealthController {
    @GetMapping("/health")
    fun health(): HealthResponse = HealthResponse(
        success = true,
        service = "agent-os-api",
        status = "ok",
    )
}
