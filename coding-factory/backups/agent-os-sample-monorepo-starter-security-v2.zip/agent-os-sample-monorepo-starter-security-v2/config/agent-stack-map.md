# Agent Stack Map — Security-Integrated v2

## Chain of command
1. **You** — strategy, priorities, approvals, explicit risk acceptance
2. **Chief of Staff** — portfolio control, intake control, escalation, workload control, security-by-design enforcement
3. **Main Orchestrator** — lifecycle routing, earliest-missing-gate enforcement, functional + security gate control
4. **Subagents** — architect, web, mobile, API/data, QA/test, platform/release, security/compliance

## Prompt stack
- `prompts/chief-of-staff/`
- `prompts/launcher/`
- `prompts/main-agent/`
- `prompts/security-compliance-agent/`

## Skill stack
- `skills/orchestrator/`
- `skills/enforcement/`
- `skills/security-gates/`
- `skills/roles/`
- `skills/domain/`

## Security rule
Security gates are part of the **default factory route**, not an optional review lane.
