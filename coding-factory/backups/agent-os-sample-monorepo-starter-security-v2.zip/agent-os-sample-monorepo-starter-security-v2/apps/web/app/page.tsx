export default function HomePage() {
  return (
    <main style={{ padding: 32, fontFamily: "sans-serif" }}>
      <h1>Agent OS Web Starter</h1>
      <p>This sample app is the browser front end in the monorepo starter.</p>
      <ul>
        <li>Next.js App Router</li>
        <li>Vitest for unit tests</li>
        <li>Playwright for end-to-end checks</li>
      </ul>
    </main>
  );
}
