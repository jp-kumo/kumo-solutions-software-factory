import { render, screen } from "@testing-library/react-native";
import App from "../App";

describe("App", () => {
  it("renders the starter heading", () => {
    render(<App />);
    expect(screen.getByText(/Agent OS Mobile Starter/i)).toBeTruthy();
  });
});
