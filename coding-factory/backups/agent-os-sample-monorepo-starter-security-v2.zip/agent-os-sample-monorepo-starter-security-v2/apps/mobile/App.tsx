import { StatusBar } from "expo-status-bar";
import { SafeAreaView, Text, View } from "react-native";

export default function App() {
  return (
    <SafeAreaView style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
      <View>
        <Text accessibilityRole="header">Agent OS Mobile Starter</Text>
        <Text>Expo / React Native sample app for the monorepo starter.</Text>
      </View>
      <StatusBar style="auto" />
    </SafeAreaView>
  );
}
