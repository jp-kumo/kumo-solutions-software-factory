# Recommended Install Order (Security-Integrated v2)

1. Read `README.md`
2. Read `docs/quick-start.md`
3. Read `docs/security-baseline.md`
4. Install `prompts/chief-of-staff/`
5. Install `prompts/launcher/`
6. Install `prompts/main-agent/`
7. Install `skills/orchestrator/master-orchestrator-skill/`
8. Install `skills/enforcement/`
9. Install `skills/security-gates/`
10. Install `skills/roles/`
11. Stand up the Slack assets from `slack/`
12. Run one pilot project with all gates active
