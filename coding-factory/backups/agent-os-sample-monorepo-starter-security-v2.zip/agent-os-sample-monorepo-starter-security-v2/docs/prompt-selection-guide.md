# Prompt Selection Guide: Full Governance vs Short Production Variant

This guide explains **when to use the full main-agent system prompt** versus the **short production variant**.

## Recommendation in one sentence
Use the **full governance prompt** when the work is ambiguous, risky, new, cross-functional, release-sensitive, or politically important inside the team. Use the **short production variant** when the workflow is already stable and you want lower token cost for routine execution.

## The practical difference
### Full governance prompt
Best for:
- greenfield products
- new teams or newly installed skill packs
- vague or incomplete requests
- major architecture decisions
- multi-team coordination
- regulated or security-sensitive work
- release approval
- production incidents
- post-release reviews
- periods when the team is drifting or skipping gates

What it gives you:
- the clearest routing logic
- the most explicit stage definitions
- the strongest anti-bypass behavior
- the highest consistency for handoffs
- the best artifact discipline for audits and retrospectives

Tradeoff:
- more tokens per interaction
- more repetition in routine delivery
- slightly slower feeling day-to-day because it restates governance more often

### Short production variant
Best for:
- mature projects using a stable stack
- routine feature delivery
- small bug fixes with already-known context
- implementation follow-through after earlier gates are already complete
- daily operational use where cost and latency matter
- long-running Slack-based coordination where the main agent responds frequently

What it gives you:
- lower token overhead
- faster routing decisions
- less repetitive governance text
- easier use for steady-state execution

Tradeoff:
- less explanatory scaffolding
- weaker recovery if the team starts drifting
- more reliance on already-established team habits

## Decision framework
Choose the **full governance prompt** when **two or more** of these are true:
- the request is ambiguous or underspecified
- the delivery stage is unclear
- architecture is still fluid
- multiple sub-agents must coordinate tightly
- user or stakeholder risk is high
- release approval is part of the ask
- a production bug or incident is involved
- a new repository, product, or workflow is being bootstrapped
- the team has recently bypassed gates or produced weak handoffs

Choose the **short production variant** when **most** of these are true:
- the stage is already clear
- earlier gate artifacts already exist
- the work is narrow and execution-oriented
- the responsible role skill is obvious
- the request is not asking for release approval
- the risk is low to moderate
- the team is following the templates consistently

## Best operating pattern
### Pattern A: Full for governance, short for execution
This is the default pattern I recommend.

Use the **full prompt** for:
- initial intake
- feature definition
- architecture review
- contract definition
- QA gate reviews
- release readiness
- incidents
- post-release review

Switch to the **short prompt** for:
- implementation follow-ups
- routine coordination updates
- code-review routing
- test follow-ups after the plan already exists
- small scope clarifications during active execution

### Pattern B: Full-time full governance
Use the **full prompt all the time** when:
- the team is new
- the repo is chaotic
- you are in a regulated or high-risk domain
- you are still tuning the handoff skills
- you want the main agent to behave conservatively at all times

### Pattern C: Mostly short, escalate to full
Use the **short prompt by default** and switch temporarily to the **full prompt** when:
- the agent says stage is unclear
- two agents disagree
- release is requested
- incident handling begins
- artifacts conflict
- architecture changes midstream
- the main agent returns repeated NO-GO results and you need richer guidance

## Specific usage guidance by scenario
### Scenario 1: New product or greenfield app
Use the **full governance prompt**.
Reason: stage clarity, architecture discipline, and role boundaries matter most early.

### Scenario 2: Existing app, routine feature already scoped
Use the **short production variant**.
Reason: the earlier gates should already be present, so you mainly want efficient orchestration.

### Scenario 3: User says “build this now” with little detail
Use the **full governance prompt**.
Reason: the agent must resist skipping feature brief, architecture, and contract work.

### Scenario 4: Small bug fix with clear reproduction and known owner
Use the **short production variant**.
Reason: the orchestration path is short and likely well understood.

### Scenario 5: Release day
Use the **full governance prompt**.
Reason: rollback, monitoring, risk framing, and explicit GO / NO-GO behavior matter more than token savings.

### Scenario 6: Production incident
Use the **full governance prompt**.
Reason: incidents benefit from stricter structure, stronger communication discipline, and more explicit ownership.

### Scenario 7: Daily Slack coordination for work already in motion
Use the **short production variant**.
Reason: you want consistent summaries without paying the full governance tax every time.

### Scenario 8: Team quality is slipping
Use the **full governance prompt** until the handoffs stabilize again.
Reason: the fuller prompt acts like guardrails when habits are weak.

## Simple policy you can adopt
Use this policy unless you want more nuance:

- **Default:** short production variant
- **Escalate to full:** intake, architecture, release, incident, post-release review, or whenever stage/gates are unclear
- **Stay on full until stabilized:** after major drift, repeated bypass attempts, or weak test/release evidence

## Switching rule for the main agent
If you want a simple internal rule, use this:

> Start with the short production variant for normal operations. Switch to the full governance prompt whenever the main agent cannot confidently identify the stage, the earliest missing gate, and the next owner in one pass.

## What not to do
- Do not use the short prompt as an excuse to skip enforcement skills.
- Do not use the full prompt for every tiny interaction if you care about latency and token cost.
- Do not switch prompts randomly; tie the switch to delivery stage and risk.
- Do not use the short prompt during release approval or incident command unless the project is extremely low risk.

## My recommendation for your setup
Given your goal of running a disciplined sub-agent team under a main agent:
- use the **full governance prompt** to establish the operating model and for all critical gates,
- use the **short production variant** for the majority of day-to-day execution,
- let the **master orchestrator skill** be the stable backbone in both modes,
- treat the short prompt as the cost-optimized runtime mode and the full prompt as the governance mode.
