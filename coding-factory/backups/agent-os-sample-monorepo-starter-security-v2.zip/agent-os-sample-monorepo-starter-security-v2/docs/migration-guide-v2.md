# Migration Guide to Security-Integrated v2

Use this guide if you previously downloaded the earlier Coding Factory packs.

## Replace these components with the v2 versions
- Chief of Staff prompt
- Launcher prompt
- Main-agent full governance prompt
- Main-agent short production prompt
- Main-agent assembled prompt stack
- Master Orchestrator skill
- Default output schema

## Add these components if they were not installed before
- `skills/security-gates/`
- `prompts/security-compliance-agent/`
- `docs/security-baseline.md`

## Operational change
Security is now part of the **default routing logic**.  
The orchestrator can block work for missing security design artifacts, incomplete reviews, or unresolved release-blocking findings.

## Superseded standalone bundles
The earlier standalone bundles are still useful for reference, but this v2 package should be treated as the **single source of truth** going forward.
