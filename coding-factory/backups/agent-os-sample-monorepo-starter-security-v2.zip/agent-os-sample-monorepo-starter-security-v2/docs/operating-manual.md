# Team Subagent Operating Manual
## Production-Quality Web and Mobile App Delivery
**March 2026 Edition**

Designed for a main orchestration agent managing specialist sub-agents through structured delivery, testing, release discipline, and Slack-based collaboration.

**Standard stack:**  
- **Web:** Next.js App Router + TypeScript  
- **Mobile:** Expo + React Native + TypeScript  
- **Backend:** Kotlin + Spring Boot  
- **Data:** PostgreSQL  
- **Testing:** Vitest, React Testing Library, Playwright, Jest, React Native Testing Library, Maestro, Detox (for high-native-risk flows)  
- **Delivery:** Git-based workflow, CI/CD pipelines, Slack as control plane

---

## 1. Purpose and Scope

This manual defines how a team of sub-agents should plan, build, test, review, release, and operate production-quality web and mobile applications under the supervision of a single main agent.

The goal is **disciplined, repeatable execution** rather than ad hoc coding. This operating model favors:

- specification before implementation
- contract-first design
- explicit quality gates
- stable, long-lived technologies
- traceable handoffs
- Slack for coordination, not as the source of truth for code or architecture

---

## 2. Operating Principles

### 2.1 Specification before implementation
No production coding begins until the feature brief, acceptance criteria, constraints, and technical approach are explicit.

### 2.2 Contracts before integration
API schemas, event payloads, database contracts, and auth assumptions are agreed before service and UI integration.

### 2.3 Testing is designed up front
Testing is not a cleanup step after coding. QA defines the required evidence before implementation begins.

### 2.4 Small changes win
Prefer small, reviewable increments with rollback paths over large, high-risk batches.

### 2.5 Production quality includes operability
Logging, metrics, tracing, migrations, error handling, and rollback plans are part of the deliverable.

### 2.6 Slack is the control plane; Git is the system of record
Slack holds dispatches, decisions, blockers, and daily status. Git holds code, architecture docs, ADRs, and pull requests.

---

## 3. Standard Technology Stack

The standard stack intentionally favors mature, widely adopted technologies with strong documentation, stable ecosystems, and long-term maintainability.

### 3.1 Web
- **Framework:** Next.js App Router
- **Language:** TypeScript
- **UI testing:** Vitest + React Testing Library
- **Browser E2E:** Playwright

### 3.2 Mobile
- **Framework:** Expo + React Native
- **Language:** TypeScript
- **Component testing:** Jest + React Native Testing Library
- **Mobile E2E:** Maestro on EAS Workflows
- **High-native-risk E2E:** Detox when deep native synchronization is required

### 3.3 Backend
- **Language:** Kotlin
- **Framework:** Spring Boot
- **API style:** REST by default, contract-first
- **Background jobs:** idempotent workers with explicit retry policy

### 3.4 Data
- **Primary database:** PostgreSQL
- **Migrations:** versioned and reversible where practical
- **Access:** SQL-first thinking; avoid hiding core query behavior behind magic

### 3.5 Platform
- **CI/CD:** pipeline-driven promotion across environments
- **Config:** environment-based configuration and secrets management
- **Artifacts:** immutable build outputs
- **Infrastructure:** Terraform where infrastructure automation is needed

### 3.6 Exceptions policy
Any deviation from the standard stack requires an ADR approved by:
- main agent
- architect agent
- platform or security agent when relevant

The burden of proof is on the exception.

---

## 4. Team Structure

### 4.1 Core structure
The default operating model uses one main agent and six core specialist agents:

1. Main Agent
2. Architect Agent
3. Web Agent
4. Mobile Agent
5. API/Data Agent
6. QA/Test Automation Agent
7. Platform/Release Agent

### 4.2 Optional specialist
Add a **Security/Compliance Agent** when the product handles:
- regulated data
- enterprise SSO
- payments
- healthcare
- privacy-sensitive workflows
- elevated customer or infrastructure risk

---

## 5. Role Charters

## 5.1 Main Agent
**Mission:** Own scope, sequencing, handoffs, release readiness, and final judgment.

**Owns:**
- backlog and prioritization
- acceptance criteria approval
- assignment of work to sub-agents
- release go/no-go
- escalation and blocker resolution

**Does not own:**
- detailed implementation in every codebase area
- bypassing quality gates without documented rationale

## 5.2 Architect Agent
**Mission:** Turn product intent into a durable technical design.

**Owns:**
- RFCs and ADRs
- service boundaries
- domain model
- API and event contracts
- non-functional requirements
- scalability and operability considerations

## 5.3 Web Agent
**Mission:** Deliver accessible, maintainable, production-quality web UX.

**Owns:**
- UI architecture for web
- forms, validation, and interaction patterns
- accessibility and semantic markup
- browser performance and rendering quality
- web test coverage

## 5.4 Mobile Agent
**Mission:** Deliver reliable, user-centered mobile app experiences across iOS and Android.

**Owns:**
- navigation flows
- offline-aware UX when required
- device capability integration
- mobile test coverage
- build and release coordination with Platform Agent

## 5.5 API/Data Agent
**Mission:** Deliver trustworthy business logic, contracts, and persistence.

**Owns:**
- API endpoints
- data modeling
- migrations
- service logic
- error handling
- transactional consistency
- idempotency and background job correctness

## 5.6 QA/Test Automation Agent
**Mission:** Define and verify the evidence required to claim production quality.

**Owns:**
- test strategy
- test matrix
- automation depth by risk
- flake reduction
- release evidence
- defect triage and regression coverage

## 5.7 Platform/Release Agent
**Mission:** Make environments, builds, promotion, and rollback boring and repeatable.

**Owns:**
- CI/CD
- artifact generation
- environment config strategy
- release pipeline
- rollback path
- runtime observability hooks

## 5.8 Security/Compliance Agent (optional)
**Mission:** Reduce security and compliance risk before release, not after incident.

**Owns:**
- threat modeling
- auth and session review
- dependency and supply chain review
- privacy-by-design checks
- secure defaults and audit evidence

---

## 6. Starter Skill Inventory by Agent

Each agent should have a deliberately small skill set that matches its charter. Skills should be narrow, reusable, and opinionated.

### Main Agent
- `product-requirements-to-prd`
- `feature-slicing-and-backlog-breakdown`
- `cross-agent-handoff-management`
- `release-readiness-gatekeeper`
- `engineering-risk-assessment`
- `incident-triage-and-prioritization`

### Architect Agent
- `system-design-rfc-writer`
- `api-contract-first-design`
- `database-schema-and-migration-design`
- `authn-authz-patterns`
- `observability-and-operability-design`
- `performance-budget-planning`

### Web Agent
- `nextjs-app-router-production-patterns`
- `react-typescript-component-design`
- `form-validation-and-state-management`
- `accessibility-and-semantic-ui`
- `react-testing-library-best-practices`
- `playwright-web-e2e`

### Mobile Agent
- `expo-react-native-production-apps`
- `navigation-and-mobile-state-patterns`
- `device-permissions-and-native-capabilities`
- `offline-and-sync-friendly-mobile-design`
- `jest-expo-and-rntl-testing`
- `maestro-mobile-e2e`

### API/Data Agent
- `spring-boot-rest-api-design`
- `kotlin-service-layer-patterns`
- `postgres-schema-design`
- `sql-query-optimization`
- `data-migrations-and-rollbacks`
- `openapi-contracts-and-client-generation`

### QA/Test Automation Agent
- `test-strategy-and-risk-based-test-planning`
- `unit-vs-integration-vs-e2e-boundaries`
- `playwright-api-and-ui-testing`
- `mobile-e2e-with-maestro`
- `detox-for-native-critical-paths`
- `flake-triage-and-test-stability`

### Platform/Release Agent
- `ci-cd-pipeline-design`
- `environment-promotion-and-config-management`
- `docker-and-runtime-packaging`
- `release-candidate-management`
- `rollback-and-disaster-recovery-checks`
- `observability-pipelines`

### Security/Compliance Agent
- `threat-modeling`
- `secure-code-review`
- `dependency-and-supply-chain-review`
- `privacy-by-design`
- `auth-session-and-token-review`
- `audit-logging-requirements`

---

## 7. Delivery Lifecycle

Every feature follows the same lifecycle. No agent may skip stages without explicit approval from the main agent.

## 7.1 Stage 0 — Intake
**Owner:** Main Agent

**Artifacts**
- problem statement
- target user
- business goal
- scope and constraints
- priority and timeline assumptions

**Exit criteria**
- feature has a unique ID
- request has a named owner
- acceptance criteria are drafted

## 7.2 Stage 1 — Definition
**Owners:** Main Agent + Architect Agent + QA Agent

**Artifacts**
- feature brief
- acceptance criteria
- technical approach
- test strategy
- risk classification

**Exit criteria**
- no material ambiguity in scope
- technical direction chosen
- QA evidence expectations documented

## 7.3 Stage 2 — Contract
**Owners:** Architect Agent + API/Data Agent

**Artifacts**
- API contract
- schema definitions
- auth assumptions
- data model updates
- migration plan

**Exit criteria**
- consumers and producers agree on contract
- migration strategy reviewed
- error model defined

## 7.4 Stage 3 — Implementation
**Owners:** Web, Mobile, API/Data Agents

**Artifacts**
- code
- tests
- docs
- observability additions
- feature flags if applicable

**Exit criteria**
- implementation complete
- tests added
- no known untracked edge cases

## 7.5 Stage 4 — Verification
**Owners:** QA Agent + owning implementation agent

**Artifacts**
- test results
- defect list
- release evidence
- flake notes if any

**Exit criteria**
- quality gates pass
- critical and high defects resolved or explicitly waived
- release risk accepted

## 7.6 Stage 5 — Release
**Owners:** Platform Agent + Main Agent

**Artifacts**
- release candidate
- deployment notes
- rollback notes
- monitoring checklist

**Exit criteria**
- deployment completed
- smoke tests pass
- observability baseline reviewed

## 7.7 Stage 6 — Post-release review
**Owners:** Main Agent + QA Agent + Platform Agent

**Artifacts**
- incident summary if needed
- regression notes
- follow-up backlog items
- lessons learned

**Exit criteria**
- production outcome captured
- follow-up work routed

---

## 8. Definition of Done

A feature is **not done** unless all of the following are true:

- acceptance criteria are satisfied
- types, lint, and formatting checks pass
- required unit and integration tests pass
- required E2E tests pass
- observability is present where needed
- migrations are documented and safe
- sensitive data is not exposed
- rollback plan exists
- release notes and handoff notes exist
- next owner is clear if more work remains

---

## 9. Coding Standards

### 9.1 General rules
- Prefer clear code over clever code.
- Prefer explicit contracts over hidden conventions.
- Keep functions and components narrow in responsibility.
- Remove dead code and speculative abstractions.
- Do not merge incomplete work without an intentional feature flag or branch policy.

### 9.2 Web standards
- Prefer server-first patterns where they simplify data loading and security.
- Validate form inputs at both client and server boundaries.
- Prefer accessible primitives and semantic markup.
- Treat browser performance and bundle size as first-class concerns.

### 9.3 Mobile standards
- Design for low-connectivity and retry conditions when product requirements imply it.
- Avoid fragile navigation logic.
- Handle permissions explicitly and degrade gracefully.
- Treat crashes, hangs, and startup failures as release blockers for critical paths.

### 9.4 Backend standards
- Validate every boundary: params, headers, bodies, and domain invariants.
- Treat migrations as production changes with rollback risk.
- Prefer idempotent background operations.
- Use structured errors and structured logging.

### 9.5 Database standards
- Model for correctness first, performance second, convenience third.
- Review indexes intentionally.
- Avoid silent destructive migrations.
- Document data retention and cleanup assumptions.

---

## 10. Testing Standards

## 10.1 Testing philosophy
Test in layers. Use the cheapest test that gives strong confidence.

### 10.2 Required layers
**Unit tests**
- pure logic
- validation
- edge-case behavior
- helper functions

**Component tests**
- user interactions
- state transitions
- rendering logic
- accessibility expectations

**Integration tests**
- API contracts
- database boundaries
- auth flows
- service orchestration

**E2E tests**
- critical user journeys
- high-risk workflows
- login
- checkout or payment equivalents
- create/edit/delete flows
- release smoke paths

## 10.3 Web testing policy
- Unit and component tests use Vitest and React Testing Library.
- Browser E2E uses Playwright.
- Avoid brittle selectors; prefer user-facing locators and explicit contracts.
- Avoid fixed sleeps.

## 10.4 Mobile testing policy
- Component and integration-style tests use Jest and React Native Testing Library.
- Default E2E uses Maestro on EAS Workflows.
- Use Detox for flows where deeper native synchronization is worth the extra complexity.

## 10.5 Test evidence requirements
Every meaningful feature PR should declare:
- tests added or updated
- what risks are covered
- what risks remain uncovered
- what manual checks, if any, were performed

## 10.6 Flake policy
- flaky tests do not count as coverage
- repeated flakes are defects
- quarantine only with owner, ticket, reason, and expiry date

---

## 11. Pull Request and Branch Policy

### 11.1 Branch rules
- one feature or defect per branch
- short-lived branches preferred
- main or trunk must stay releasable

### 11.2 PR rules
Every PR must include:
- summary of change
- why the change exists
- risk assessment
- screenshots or build evidence when relevant
- test evidence
- rollback considerations

### 11.3 Review rules
- reviewer checks correctness, maintainability, and risk
- QA checks evidence quality, not just quantity
- security or platform review is required when risk profile demands it

---

## 12. Slack Operating System

Slack is the coordination layer for the main agent and sub-agents.

## 12.1 Channel layout

### Global
- `#agent-control-tower`
- `#agent-announcements`

### Per product or program
- `#proj-<name>-intake`
- `#proj-<name>-arch`
- `#proj-<name>-web`
- `#proj-<name>-mobile`
- `#proj-<name>-api`
- `#proj-<name>-qa`
- `#proj-<name>-release`
- `#proj-<name>-incidents`

## 12.2 Channel purpose
**Control tower**
- top-level dispatches
- daily status rollups
- escalations
- decision requests

**Intake**
- new requests
- bug reports
- clarifications
- scope triage

**Architecture**
- RFCs
- ADRs
- trade-off discussions

**Implementation channels**
- role-specific execution discussions
- handoffs
- blockers

**Release**
- promotion status
- release candidate evidence
- go/no-go decisions

**Incidents**
- outages
- regression coordination
- hotfix command thread

## 12.3 Slack rules
- One feature gets one top-level dispatch post.
- All execution discussion happens in the thread.
- Decisions are summarized in the channel after the thread resolves.
- No code review in Slack if Git tooling is available.
- No architecture source of truth in chat alone; final decisions go to ADRs or canvases.

## 12.4 Canvases and lists
Each project should have:
- a project canvas
- a release checklist canvas
- an architecture decisions canvas or linked ADR index
- a work-tracking list with states:
  - backlog
  - in progress
  - blocked
  - review
  - release-ready
  - shipped

## 12.5 Workflow automation
Create Slack workflows or forms for:
- feature intake
- bug intake
- release request
- incident declaration
- post-release review reminder

---

## 13. Daily and Weekly Operating Rhythm

## 13.1 Daily control tower post
The main agent posts one daily status summary with:
- shipped yesterday
- in progress today
- blocked items
- risks
- decisions needed
- next release target

## 13.2 Weekly architecture review
The architect agent and main agent review:
- major active RFCs
- stack exceptions
- scaling or operability risks
- cross-team integration risks

## 13.3 Weekly quality review
The QA and Platform agents review:
- test failure trends
- flaky tests
- release regressions
- environment instability
- escaped defects

---

## 14. Handoff Contract

Every sub-agent handoff must use the same structure.

## 14.1 Required handoff fields
- **Task ID**
- **Objective**
- **Owner**
- **Inputs**
- **Assumptions**
- **Artifacts created**
- **Tests added or updated**
- **Risks**
- **Open questions**
- **Recommended next owner**
- **Ready for next agent?** yes/no

## 14.2 Handoff example

```md
Task ID: FEAT-142
Objective: Add password reset flow for web and mobile.
Owner: API/Data Agent
Inputs:
- Approved feature brief FEAT-142
- Auth RFC ADR-019
- API contract draft v2
Assumptions:
- Email delivery provider remains unchanged
- Token TTL is 30 minutes
Artifacts created:
- `/services/auth/reset-password.kt`
- `/openapi/auth.yaml`
- migration `2026_03_01_add_reset_tokens.sql`
Tests added or updated:
- unit tests for token generation and expiration
- integration tests for reset request and reset confirm endpoints
Risks:
- email deliverability not fully validated in staging
Open questions:
- should the token be invalidated on password change from all devices?
Recommended next owner: Web Agent
Ready for next agent?: yes
```

---

## 15. Templates

## 15.1 Feature dispatch template

```md
Feature ID: FEAT-###
Goal:
Primary user:
Business value:
Priority:
Owner agent:
Dependencies:
Acceptance criteria:
Risks:
Requested artifacts:
Due gate:
```

## 15.2 QA test plan template

```md
Feature ID:
Risk level: low / medium / high
Critical paths:
Unit coverage required:
Integration coverage required:
E2E coverage required:
Negative cases:
Accessibility checks:
Performance checks:
Manual checks:
Release evidence required:
```

## 15.3 Release go/no-go template

```md
Release ID:
Scope:
Environment:
Build artifact:
Migrations included:
Feature flags:
Quality gate summary:
Open defects:
Rollback steps:
Monitoring checks:
Decision: go / no-go
Approver:
```

## 15.4 Incident command template

```md
Incident ID:
Start time:
Severity:
Impact:
Suspected cause:
Current mitigation:
Owner:
Next update time:
```

---

## 16. Metrics

The team should track a small number of operational metrics:

- lead time from intake to release
- deployment frequency
- change failure rate
- escaped defect count
- flaky test count
- rollback count
- mean time to recovery
- percent of work with complete handoff evidence

Do not over-instrument the process before the basics are stable.

---

## 17. Governance Rules

### 17.1 Who can waive a gate
Only the main agent can waive a delivery gate, and every waiver must be recorded with:
- reason
- scope
- risk
- mitigation
- expiry or follow-up owner

### 17.2 When to require architect review
Require architect review when:
- a new service boundary is introduced
- schema changes are high risk
- auth changes affect multiple clients
- performance or scale assumptions materially change
- a non-standard technology is proposed

### 17.3 When to require security review
Require security review when:
- auth or session logic changes
- permissions model changes
- sensitive data handling changes
- new external vendors or SDKs are introduced
- secrets or cryptographic behavior changes

---

## 18. 30-Day Bootstrap Plan

## Days 1–7
- create Slack channel structure
- create canvases and lists
- define role charters
- set branch policy
- define feature and PR templates

## Days 8–14
- create starter skill files for each agent
- create first ADR template
- standardize API response and error format
- wire baseline CI for lint, typecheck, and unit tests

## Days 15–21
- add integration and E2E pipelines
- define release checklist
- define incident channel protocol
- add structured logging and health checks

## Days 22–30
- run one pilot feature end to end
- conduct a post-release review
- tune handoff templates
- remove process friction that does not improve quality

---

## 19. Final Guidance

A strong sub-agent team is not created by adding more agents. It is created by:
- narrowing responsibilities
- forcing clear handoffs
- standardizing evidence
- using a durable stack
- keeping the main agent in charge of sequencing and release judgment

If a sub-agent team feels chaotic, the answer is usually not more autonomy. The answer is better contracts, smaller work units, and stricter done criteria.
