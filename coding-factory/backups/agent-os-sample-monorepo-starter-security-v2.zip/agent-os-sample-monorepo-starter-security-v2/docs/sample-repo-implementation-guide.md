# Sample Repo Implementation Guide

## Purpose

This guide explains how to use the sample monorepo layer that sits on top of the Agent OS governance assets.

## Design goals

- Keep the code layout boring and durable.
- Keep frontend and mobile in TypeScript.
- Keep the backend in Kotlin + Spring Boot.
- Keep data contracts explicit and versionable.
- Keep local development simple.

## Application boundaries

### `apps/web`
- Server-rendered and client-rendered web UI
- Browser-facing auth/session handling
- Playwright UI and smoke coverage

### `apps/mobile`
- Mobile UI and navigation
- Device-only concerns such as permissions and deep linking
- Jest / React Native Testing Library and Maestro coverage

### `services/api`
- Domain logic
- Persistence
- Authz/authn enforcement
- Background jobs later, if needed

### `packages/contracts`
- OpenAPI definitions
- Shared JSON schemas
- Example payloads later

## Suggested next implementation steps

1. Add real domain entities to `packages/contracts/openapi/app-api.yaml`.
2. Replace the sample health and task endpoints with your actual domain.
3. Add auth and role checks in the API service.
4. Add design system tokens and real routes/screens.
5. Connect CI secrets and deployment environments.
