# Security Baseline for the Coding Factory (March 2026)

This package treats security as a **default delivery gate**, not an optional review lane.

## Mandatory baselines
- **OWASP Top 10:2025** — baseline web/application risk awareness
- **OWASP ASVS 5.0.0** — application security verification mapping
- **OWASP API Security Top 10 2023** — API-specific design and review checks
- **OWASP MASVS** — mobile application security verification
- **NIST SSDF 1.1** — secure software development process baseline
- **CISA Secure by Design** — program-level secure-by-design principles

## Security gates now built into the default workflow
1. Security design intake
2. Threat model / abuse case review
3. OWASP Top 10 review
4. ASVS control mapping
5. API Top 10 review when APIs are in scope
6. MASVS review when mobile is in scope
7. Security findings triage and risk acceptance
8. Security release gate with explicit **GO / CONDITIONAL GO / NO-GO**

## Factory rule
No implementation or release may proceed when the **earliest missing gate** is a required security gate.

## Required companion assets in this package
- `prompts/chief-of-staff/`
- `prompts/security-compliance-agent/`
- `skills/security-gates/`
- `skills/orchestrator/master-orchestrator-skill/`
- `schemas/default-output-schema.json`
