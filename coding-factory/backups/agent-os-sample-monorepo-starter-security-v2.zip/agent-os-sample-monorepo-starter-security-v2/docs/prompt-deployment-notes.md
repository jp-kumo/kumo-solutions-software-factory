# Prompt Deployment Notes — Security-Integrated v2

## Recommended stack
- **Chief of Staff prompt** for portfolio control and escalation
- **Launcher prompt** for routing between short and full governance mode
- **Main-agent prompts** for orchestration
- **Security/Compliance Agent prompt** for security-specific review and enforcement

## Default behavior
The launcher should select **FULL GOVERNANCE MODE** when:
- required artifacts are missing
- risk is unclear
- release readiness is in question
- a required security gate is open
- critical or high-severity findings are unresolved

## Schema
Use `schemas/default-output-schema.json` for status and gate outputs.
