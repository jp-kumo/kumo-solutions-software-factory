# Agent OS Sample Monorepo Starter — Security-Integrated v2

This starter extends the Coding Factory operating-system package with a runnable sample monorepo and the **security-integrated v2 control layer**.

## Included application structure
- `apps/web` — Next.js App Router web app in TypeScript
- `apps/mobile` — Expo / React Native mobile app in TypeScript
- `services/api` — Kotlin + Spring Boot API service
- `packages/contracts` — OpenAPI and JSON Schema contracts
- `infra/local` — local Postgres via Docker Compose
- `.github/workflows` — starter CI skeleton

## Included governance structure
- Security-integrated launcher, main-agent, and chief-of-staff prompts
- Security-integrated master orchestrator skill
- Handoff-enforcement skills
- Security gate skills
- Slack templates
- Handoff templates
- Security baseline and migration docs

## Use this package when
- you want the operating system **and**
- you want the sample repo scaffold in one bundle

## Single source of truth rule
Use this v2 monorepo starter instead of the earlier monorepo starter if you want your project scaffold to match the current security-integrated operating model.
